# Lab 2: hevc-intra-stego

Huong dan day du da duoc chuyen sang file HTML theo mau PTIT:

```text
HUONG_DAN_SINH_VIEN.html
```

Mo file HTML do trong trinh duyet de doc ban huong dan chinh thuc.

Phien ban hien tai da duoc dieu chinh de bai lam da dang hon:

- quan sat trace bang `head`, `grep`, `awk`;
- parse va thao tac CSV;
- chon candidate bang cong cu co san;
- sua hai file Python nho o phan nhung va tach tin;
- do impact bang cong cu ho tro sau cung.
