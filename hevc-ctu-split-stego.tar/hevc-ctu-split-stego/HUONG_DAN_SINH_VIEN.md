# Lab: hevc-ctu-split-stego

## 1. Giới thiệu

Tên lab: `hevc-ctu-split-stego`

Chủ đề: điều tra video H.265 nghi bị dùng làm kênh giấu tin trong cấu trúc phân chia CTU/CU.

Vai trò của sinh viên là analyst điều tra trace CTU đáng ngờ. Thay vì chỉ nhúng rồi tách tin theo một pipeline cố định, bài lab yêu cầu so sánh evidence sạch và evidence nghi vấn, xác định vùng CTU bị tác động, khôi phục thứ tự carrier và kết luận kỹ thuật giấu tin.

Mục tiêu:

- Hiểu CTU/CU quadtree và `split_flag` trong HEVC.
- Biết vì sao thay đổi quyết định split ở vùng texture trung bình có thể tạo kênh giấu tin.
- So sánh clean/suspect trace để phát hiện số CTU bị thay đổi.
- Tạo heatmap không gian để khoanh vùng carrier đáng ngờ.
- Hoàn thiện extractor để khôi phục thông điệp `CTU3`.
- Viết kết luận incident theo bằng chứng thu được.

## 2. Kiến thức cần nắm

HEVC chia frame thành các Coding Tree Unit (CTU). Mỗi CTU có thể tiếp tục chia thành các Coding Unit (CU) nhỏ hơn theo cây tứ phân. Quyết định chia hay không chia được biểu diễn bằng `split_flag`.

Trong bài lab này, attacker không sửa trực tiếp pixel. Dữ liệu ẩn được mô phỏng bằng các thay đổi có chủ đích trong `split_flag` của các CTU thuộc vùng `medium_texture`. Quy ước đọc bit:

- `split_flag = 0` biểu diễn bit `0`.
- `split_flag = 1` biểu diễn bit `1`.
- Carrier được đọc theo thứ tự `frame -> y -> x`.

## 3. Dữ liệu trong lab

Vào thư mục làm bài:

```bash
cd /home/ubuntu
ls
```

Nếu chưa thấy dữ liệu evidence, tạo lại bằng:

```bash
python3 tools/make_evidence.py
```

Các file quan trọng:

- `evidence/ctu_clean_trace.log`: trace CTU baseline.
- `evidence/ctu_suspect_trace.log`: trace CTU nghi vấn.
- `evidence/case_note.txt`: ghi chú điều tra gồm kỹ thuật và vùng nghi vấn.
- `message/secret.txt`: thông điệp mẫu dùng để kiểm chứng.
- `tools/`: công cụ parse, triage, heatmap, carrier order, extractor và answer check.
- `report/`: nơi lưu kết quả để `checkwork` chấm.

## 4. Tải và khởi động lab

Cách khuyến nghị:

```bash
imodule https://raw.githubusercontent.com/letienduong/stegnography/main/hevc-ctu-split-stego.tar
labtainer -r hevc-ctu-split-stego
```

Nếu máy đã có bản cũ, nên gỡ container/image cũ trước khi tải lại:

```bash
stoplab hevc-ctu-split-stego
docker rm -f hevc-ctu-split-stego.hevc-ctu-split-stego.student hevc-ctu-split-stego-igrader 2>/dev/null
docker rmi -f b22dcat063/hevc-ctu-split-stego.hevc-ctu-split-stego.student 2>/dev/null
rm -rf ~/labtainer/trunk/labs/hevc-ctu-split-stego
imodule https://raw.githubusercontent.com/letienduong/stegnography/main/hevc-ctu-split-stego.tar
labtainer -r hevc-ctu-split-stego
```

## 5. Nhiệm vụ 1 - evidence_triage

Mục đích: parse trace sạch và trace nghi vấn, sau đó đếm số CTU có `split_flag` bị thay đổi.

```bash
mkdir -p report
python3 tools/parse_ctu_trace.py evidence/ctu_clean_trace.log --csv report/clean_ctu.csv > report/clean_summary.txt
python3 tools/parse_ctu_trace.py evidence/ctu_suspect_trace.log --csv report/suspect_ctu.csv > report/suspect_summary.txt
python3 tools/evidence_triage.py report/clean_ctu.csv report/suspect_ctu.csv > report/evidence_triage.txt
cat report/evidence_triage.txt
```

Kết quả cần thấy:

```text
EVIDENCE_DIFF=split_flag_changes:8
```

## 6. Nhiệm vụ 2 - spatial_anomaly_heatmap

Mục đích: biểu diễn vị trí các CTU bị thay đổi để xem đây là nhiễu rải rác hay một vùng carrier có chủ đích.

```bash
python3 tools/spatial_heatmap.py report/clean_ctu.csv report/suspect_ctu.csv > report/heatmap.txt
cat report/heatmap.txt
```

Kết quả cần thấy:

```text
HEATMAP_CHANGED=8
```

Trong heatmap, ký hiệu `X` là CTU có `split_flag` khác baseline, dấu `.` là CTU không đổi.

## 7. Nhiệm vụ 3 - guided_anomaly_classification

Mục đích: phân loại bất thường dựa trên region, RD risk và PSNR risk. Sinh viên cần đọc `evidence/case_note.txt`, `report/evidence_triage.txt` và `report/heatmap.txt` trước khi điền báo cáo phân loại.

Tạo file phân loại:

```bash
nano report/classification.txt
```

Gợi ý nội dung cần thể hiện trong file:

- `REGION`: vùng carrier nằm ở medium texture.
- `RD_RISK`: mức rủi ro RD thấp.
- `PSNR_RISK`: mức rủi ro PSNR thấp.
- `VERDICT`: đây là carrier có chủ đích, không phải thay đổi ngẫu nhiên.

Kiểm tra phân loại:

```bash
python3 tools/classification_check.py report/classification.txt > report/classification_check.txt
cat report/classification_check.txt
```

Kết quả cần thấy:

```text
CLASSIFICATION_OK=targeted_carrier:medium_texture:low
```

## 8. Nhiệm vụ 4 - carrier_order_recovery

Mục đích: khôi phục thứ tự đọc carrier mà decoder/attacker dùng để lấy 32 bit thông điệp.

```bash
python3 tools/carrier_order.py report/suspect_ctu.csv --out report/carrier_order.csv > report/carrier_order.txt
cat report/carrier_order.txt
head report/carrier_order.csv
```

Kết quả cần thấy:

```text
CARRIER_ORDER=32:frame_y_x
```

## 9. Nhiệm vụ 5 - decoder_message_recovery

Mục đích: hoàn thiện extractor để đọc bit từ `split_flag` theo carrier order và khôi phục thông điệp.

Mở extractor:

```bash
nano tools/extract_split.py
```

Tìm TODO của Task 5. Gợi ý: với từng carrier hợp lệ, đọc giá trị split flag đang có trong trace nghi vấn. Giá trị `0` sinh bit `0`, giá trị `1` sinh bit `1`; bỏ qua giá trị không hợp lệ.

Chạy extractor:

```bash
python3 tools/extract_split.py report/suspect_ctu.csv report/carrier_order.csv > report/extracted.txt
cat report/extracted.txt
```

Kết quả cần thấy:

```text
EXTRACTED_MESSAGE=CTU3
```

## 10. Nhiệm vụ 6 - incident_conclusion

Mục đích: viết kết luận incident dựa trên thông điệp đã tách và ghi chú evidence.

Đọc lại evidence:

```bash
cat evidence/case_note.txt
cat report/extracted.txt
```

Tạo báo cáo trả lời:

```bash
nano report/incident_answer.txt
```

Gợi ý báo cáo cần nêu đủ:

- `message`: thông điệp đã tách.
- `technique`: kỹ thuật giấu tin trong case note.
- `region`: vùng nghi vấn trong case note.
- `confidence`: mức tin cậy cao khi bằng chứng khớp.

Kiểm tra kết luận:

```bash
python3 tools/answer_check.py report/incident_answer.txt report/extracted.txt evidence/case_note.txt > report/answer_check.txt
cat report/answer_check.txt
```

Kết quả cần thấy:

```text
ANSWER_OK=CTU3:CTU_SPLIT_FLAG:medium_texture
```

## 11. Checkwork

Trên terminal của máy Labtainer host, chạy:

```bash
checkwork hevc-ctu-split-stego
```

Checkwork của bài:

1. `evidence_triage`
2. `spatial_anomaly_heatmap`
3. `guided_anomaly_classification`
4. `carrier_order_recovery`
5. `decoder_message_recovery`
6. `incident_conclusion`
