# Lab: hevc-ctu-split-stego

Bài này là ca điều tra decoder-side: so sánh clean/suspect CTU trace, tự dựng heatmap anomaly, phân loại evidence, khôi phục carrier order, patch extractor và viết incident conclusion.

## Task 1 - evidence_triage

```bash
python3 tools/parse_ctu_trace.py evidence/ctu_clean_trace.log --csv report/clean_ctu.csv > report/clean_summary.txt
python3 tools/parse_ctu_trace.py evidence/ctu_suspect_trace.log --csv report/suspect_ctu.csv > report/suspect_summary.txt
python3 tools/evidence_triage.py report/clean_ctu.csv report/suspect_ctu.csv > report/evidence_triage.txt
```

Kết quả: `EVIDENCE_DIFF=split_flag_changes:8`.

## Task 2 - spatial_anomaly_heatmap

```bash
python3 tools/compare_split_maps.py report/clean_ctu.csv report/suspect_ctu.csv --out report/split_changes.csv > report/split_anomaly.txt
python3 tools/spatial_heatmap.py report/clean_ctu.csv report/suspect_ctu.csv > report/heatmap.txt
```

Kết quả: `HEATMAP_CHANGED=8`.

## Task 3 - guided_anomaly_classification

```bash
nano report/anomaly_classification.txt
python3 tools/classification_check.py report/anomaly_classification.txt > report/classification_check.txt
```

Kết quả: `CLASSIFICATION_OK=targeted_carrier:medium_texture:low`.

## Task 4 - carrier_order_recovery

```bash
python3 tools/carrier_order.py report/suspect_ctu.csv --bits 32 --out report/carrier_order.csv > report/carrier_order.txt
```

Kết quả: `CARRIER_ORDER=32:frame_y_x`.

## Task 5 - decoder_message_recovery

Sửa `tools/extract_split.py`:

```python
if row["split_flag"] == "0":
    bits.append("0")
elif row["split_flag"] == "1":
    bits.append("1")
```

```bash
python3 tools/extract_split.py report/suspect_ctu.csv report/carrier_order.csv > report/extracted.txt
```

Kết quả: `EXTRACTED_MESSAGE=CTU3`.

## Task 6 - incident_conclusion

Tạo `answer.txt`:

```text
message=CTU3
technique=CTU_SPLIT_FLAG
region=medium_texture
confidence=high
```

```bash
python3 tools/answer_check.py answer.txt report/extracted.txt evidence/case_note.txt > report/answer_check.txt
```

Kết quả: `ANSWER_OK=CTU3:CTU_SPLIT_FLAG:medium_texture`.
