﻿# Lab: hevc-ctu-split-stego

## 1. Giới thiệu

Tên lab: `hevc-ctu-split-stego`

Chủ đề: điều tra video H.265 nghi bị dùng làm kênh giấu tin trong cấu trúc phân chia CTU/CU.

Vai trò của sinh viên: analyst kiểm tra trace CTU đáng ngờ. Trace chứa thông tin CTU, depth, texture, `split_flag`, RD cost, bitrate và PSNR drop. Nhiệm vụ là chọn carrier hợp lý, nhúng thông điệp bằng `split_flag`, sau đó tách lại thông điệp.

Mục tiêu:

- Hiểu CTU/CU quadtree và `split_flag` trong HEVC.
- Dựng grid CTU và audit phân bố depth.
- Chọn CTU ứng viên theo texture và `epsilon = 0.10`.
- Sửa embedder/extractor để giấu và tách tin bằng split flag.
- Đo tác động tới bitrate và PSNR.

## 2. Kiến thức cần nắm

HEVC chia frame thành CTU, sau đó mỗi CTU có thể chia thành các CU nhỏ hơn theo cây tứ phân. Quyết định chia khối được mô phỏng bằng `split_flag`.

Quy tắc trong bài:

- `stego_split_flag = 0` -> bit `0`.
- `stego_split_flag = 1` -> bit `1`.
- Chỉ dùng CTU có `texture=medium` và relative RD gap không vượt `0.10`.

## 3. Dữ liệu trong lab

```bash
cd /home/ubuntu
ls
```

Thư mục quan trọng:

- `evidence/ctu_split_trace.log`: trace CTU/CU quadtree.
- `message/secret.txt`: thông điệp `CTU3`.
- `policy.txt`: chính sách chọn carrier.
- `tools/`: công cụ parse, audit, nhúng, tách và đo impact.
- `report/`: nơi lưu kết quả để checkwork chấm.

## 4. Tải và khởi động Lab

Cách khuyến nghị:

```bash
curl -L https://github.com/letienduong/stegnography/raw/refs/heads/main/install-hevc-ctu-split-stego.sh | bash
```

Hoặc:

```bash
imodule https://github.com/letienduong/stegnography/raw/refs/heads/main/hevc-ctu-split-stego.tar
```

Hoặc dùng `curl`:

```bash
curl -L https://github.com/letienduong/stegnography/raw/refs/heads/main/hevc-ctu-split-stego.tar | tar -x -C ~/labtainer/trunk/labs/
```

Khởi động lab:

```bash
labtainer -r hevc-ctu-split-stego
```

## 5. Nhiệm vụ 1 - evidence_triage

```bash
cd /home/ubuntu
python3 tools/make_evidence.py
mkdir -p report
python3 tools/parse_ctu_trace.py evidence/ctu_clean_trace.log --csv report/clean_ctu.csv > report/clean_summary.txt
python3 tools/parse_ctu_trace.py evidence/ctu_suspect_trace.log --csv report/suspect_ctu.csv > report/suspect_summary.txt
python3 tools/evidence_triage.py report/clean_ctu.csv report/suspect_ctu.csv > report/evidence_triage.txt
cat report/evidence_triage.txt
```

Kết quả đúng:

```text
EVIDENCE_DIFF=split_flag_changes:8
```

## 6. Nhiệm vụ 2 - spatial_anomaly_heatmap

Mở file heatmap và sửa TODO của Task 2:

```bash
nano tools/spatial_heatmap.py
```

Gợi ý: hàm cần trả về `X` nếu `split_flag` giữa clean trace và suspect trace khác nhau, ngược lại trả về `.`. Không cần sửa phần đọc CSV hoặc phần in kết quả.

Chạy lại heatmap:

```bash
python3 tools/spatial_heatmap.py report/clean_ctu.csv report/suspect_ctu.csv > report/heatmap.txt
cat report/heatmap.txt
```

Kết quả đúng:

```text
HEATMAP_CHANGED=8
```

## 7. Nhiệm vụ 3 - guided_anomaly_classification

Đọc bằng chứng rồi tạo file phân loại:

```bash
cat evidence/case_note.txt
cat report/evidence_triage.txt
cat report/heatmap.txt
nano report/classification.txt
```

File cần thể hiện `REGION`, `RD_RISK`, `PSNR_RISK` và `VERDICT`. Sinh viên tự điền giá trị dựa trên bằng chứng.

```bash
python3 tools/classification_check.py report/classification.txt > report/classification_check.txt
cat report/classification_check.txt
```

Kết quả đúng:

```text
CLASSIFICATION_OK=targeted_carrier:medium_texture:low
```

## 8. Nhiệm vụ 4 - carrier_order_recovery

```bash
python3 tools/carrier_order.py report/suspect_ctu.csv --out report/carrier_order.csv > report/carrier_order.txt
cat report/carrier_order.txt
head report/carrier_order.csv
```

Kết quả đúng:

```text
CARRIER_ORDER=32:frame_y_x
```

## 9. Nhiệm vụ 5 - decoder_message_recovery

Mở extractor:

```bash
nano tools/extract_split.py
```

Tìm TODO của Task 5. Gợi ý: đọc `split_flag` của từng carrier trong `report/carrier_order.csv`; `0` tạo bit `0`, `1` tạo bit `1`; bỏ qua giá trị không hợp lệ.

```bash
python3 tools/extract_split.py report/suspect_ctu.csv report/carrier_order.csv > report/extracted.txt
cat report/extracted.txt
```

Kết quả đúng:

```text
EXTRACTED_MESSAGE=CTU3
```

## 10. Nhiệm vụ 6 - incident_conclusion

```bash
cat evidence/case_note.txt
cat report/extracted.txt
nano report/incident_answer.txt
python3 tools/answer_check.py report/incident_answer.txt report/extracted.txt evidence/case_note.txt > report/answer_check.txt
cat report/answer_check.txt
```

Báo cáo trả lời cần nêu đủ `message`, `technique`, `region` và `confidence`.

Kết quả đúng:

```text
ANSWER_OK=CTU3:CTU_SPLIT_FLAG:medium_texture
```

## 11. Checkwork

```bash
checkwork hevc-ctu-split-stego
```

Checkwork của bài:

1. `evidence_triage`
2. `spatial_anomaly_heatmap`
3. `guided_anomaly_classification`
4. `carrier_order_recovery`
5. `decoder_message_recovery`
6. `incident_conclusion`
