# Lab: HEVC CTU Split Stego

Huong dan chinh thuc nam trong file:

```text
HUONG_DAN_SINH_VIEN.docx
```

Noi dung bai lab gom ly thuyet ngan ve CTU/CU quadtree, thao tac quan sat trace, chon CTU ung vien, sua TODO de nhung/tach tin bang `split_flag`, va do tac dong bitrate/PSNR.
