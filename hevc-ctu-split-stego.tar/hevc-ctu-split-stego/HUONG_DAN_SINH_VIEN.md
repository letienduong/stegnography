# Lab: hevc-ctu-split-stego

## 1. Giới thiệu

Tên lab: `hevc-ctu-split-stego`

Chủ đề: điều tra video H.265 nghi bị dùng làm kênh giấu tin trong cấu trúc phân chia CTU/CU.

Vai trò của sinh viên: analyst kiểm tra trace CTU đáng ngờ. Trace chứa thông tin CTU, depth, texture, `split_flag`, RD cost, bitrate và PSNR drop. Nhiệm vụ là chọn carrier hợp lý, nhúng thông điệp bằng `split_flag`, sau đó tách lại thông điệp.

Mục tiêu:

- Hiểu CTU/CU quadtree và `split_flag` trong HEVC.
- Dựng grid CTU và audit phân bố depth.
- Chọn CTU ứng viên theo texture và `epsilon = 0.10`.
- Sửa embedder/extractor để giấu và tách tin bằng split flag.
- Đo tác động tới bitrate và PSNR.

## 2. Kiến thức cần nắm

HEVC chia frame thành CTU, sau đó mỗi CTU có thể chia thành các CU nhỏ hơn theo cây tứ phân. Quyết định chia khối được mô phỏng bằng `split_flag`.

Quy tắc trong bài:

- `stego_split_flag = 0` -> bit `0`.
- `stego_split_flag = 1` -> bit `1`.
- Chỉ dùng CTU có `texture=medium` và relative RD gap không vượt `0.10`.

## 3. Dữ liệu trong lab

```bash
cd /home/ubuntu
ls
```

Thư mục quan trọng:

- `evidence/ctu_split_trace.log`: trace CTU/CU quadtree.
- `message/secret.txt`: thông điệp `CTU3`.
- `policy.txt`: chính sách chọn carrier.
- `tools/`: công cụ parse, audit, nhúng, tách và đo impact.
- `report/`: nơi lưu kết quả để checkwork chấm.

## 4. Tải và khởi động Lab

Cách khuyến nghị:

```bash
curl -L https://github.com/letienduong/stegnography/raw/refs/heads/main/install-hevc-ctu-split-stego.sh | bash
```

Hoặc:

```bash
imodule https://github.com/letienduong/stegnography/raw/refs/heads/main/hevc-ctu-split-stego.tar
```

Hoặc dùng `curl`:

```bash
curl -L https://github.com/letienduong/stegnography/raw/refs/heads/main/hevc-ctu-split-stego.tar | tar -x -C ~/labtainer/trunk/labs/
```

Khởi động lab:

```bash
labtainer -r hevc-ctu-split-stego
```

## 5. Nhiệm vụ 1 - CTU grid snapshot

```bash
python3 tools/parse_ctu_trace.py evidence/ctu_split_trace.log --csv report/ctu_trace.csv > report/trace_summary.txt
python3 tools/ctu_grid.py report/ctu_trace.csv --frame 0 > report/ctu_grid.txt
cat report/ctu_grid.txt
```

Kết quả đúng:

```text
CTU_GRID=5x4
```

## 6. Nhiệm vụ 2 - Quadtree depth audit

```bash
python3 tools/depth_audit.py report/ctu_trace.csv > report/depth_audit.txt
cat report/depth_audit.txt
```

Kết quả đúng:

```text
DEPTH_PATTERN=0:27,1:27,2:26
```

## 7. Nhiệm vụ 3 - Policy và capacity

```bash
cat policy.txt
python3 tools/select_candidates.py report/ctu_trace.csv --epsilon 0.10 --out report/candidates.csv > report/candidates.txt
python3 tools/policy_check.py policy.txt report/candidates.csv message/secret.txt > report/policy_check.txt
cat report/policy_check.txt
```

Kết quả đúng:

```text
POLICY_OK=medium:0.10:32
```

## 8. Nhiệm vụ 4 - Sửa embedder

Mở embedder:

```bash
nano tools/embed_split.py
```

Tìm TODO của Task 4 và thay dòng placeholder bằng:

```python
row["stego_split_flag"] = bit
```

Chạy:

```bash
python3 tools/embed_split.py report/ctu_trace.csv report/candidates.csv message/secret.txt --out evidence/stego_split.csv > report/embed_summary.txt
cat report/embed_summary.txt
```

Kết quả đúng:

```text
STEGO_SPLIT_FLAG_1=38
```

## 9. Nhiệm vụ 5 - Sửa extractor

Mở extractor:

```bash
nano tools/extract_split.py
```

Tìm TODO của Task 5 và thay `pass` bằng:

```python
if row["stego_split_flag"] == "0":
    bits.append("0")
elif row["stego_split_flag"] == "1":
    bits.append("1")
```

Chạy:

```bash
python3 tools/extract_split.py evidence/stego_split.csv > report/extracted.txt
cat report/extracted.txt
```

Kết quả đúng:

```text
EXTRACTED_MESSAGE=CTU3
```

## 10. Nhiệm vụ 6 - Đo impact

```bash
python3 tools/measure_impact.py report/ctu_trace.csv evidence/stego_split.csv > report/impact.txt
python3 tools/final_check.py report/extracted.txt report/impact.txt > report/final_check.txt
cat report/final_check.txt
```

Kết quả đúng:

```text
FINAL_STATUS=CTU3:0.06
```

## 11. Checkwork

```bash
checkwork hevc-ctu-split-stego
```

Checkwork của bài:

1. `ctu_grid_snapshot`
2. `quadtree_depth_audit`
3. `embedding_policy_capacity`
4. `split_flag_apply`
5. `split_decoder_extractor`
6. `rd_psnr_impact_report`
