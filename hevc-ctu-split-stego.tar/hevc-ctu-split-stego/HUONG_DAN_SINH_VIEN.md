﻿# Lab: hevc-ctu-split-stego

## 1. Giới thiệu Lab

Tên lab: `hevc-ctu-split-stego`

Kỹ thuật: điều tra kênh giấu tin mô phỏng bằng quyết định `split_flag` trong cấu trúc CTU/CU quadtree của HEVC.

Kết quả cần đạt: phát hiện `8` thay đổi split flag, khôi phục thông điệp `CTU3`, và kết luận kỹ thuật `CTU_SPLIT_FLAG` tại vùng `medium_texture`.

## 2. Kịch bản

Một hệ thống camera dùng video H.265 bị nghi đã trở thành kênh truyền tin ẩn. Metadata không có chuỗi bất thường, nhưng clean trace và suspect trace cho thấy một số quyết định chia CTU có dấu hiệu bị điều khiển.

Vai trò của sinh viên: analyst điều tra CTU trace đáng ngờ, khoanh vùng bất thường, khôi phục carrier order và viết kết luận incident.

## 3. Kiến thức bổ trợ

HEVC chia frame thành CTU. Mỗi CTU có thể chia tiếp thành CU theo cây tứ phân. Quyết định block có chia tiếp hay không được biểu diễn bằng `split_flag`.

Trong bài này, `split_flag = 0` biểu diễn bit 0 và `split_flag = 1` biểu diễn bit 1. Carrier được đọc theo thứ tự `frame -> y -> x`.

## 4. Tải và khởi động Lab

```bash
imodule https://raw.githubusercontent.com/letienduong/stegnography/main/hevc-ctu-split-stego.tar
labtainer -r hevc-ctu-split-stego
```

Nếu cần gỡ bản cũ:

```bash
stoplab hevc-ctu-split-stego
docker rm -f hevc-ctu-split-stego.hevc-ctu-split-stego.student hevc-ctu-split-stego-igrader 2>/dev/null
docker rmi -f b22dcat063/hevc-ctu-split-stego.hevc-ctu-split-stego.student 2>/dev/null
rm -rf ~/labtainer/trunk/labs/hevc-ctu-split-stego
imodule https://raw.githubusercontent.com/letienduong/stegnography/main/hevc-ctu-split-stego.tar
labtainer -r hevc-ctu-split-stego
```

## 5. Các nhiệm vụ

Vào thư mục làm bài:

```bash
cd /home/ubuntu
python3 tools/make_evidence.py
mkdir -p report
```

### Nhiệm vụ 1 - evidence_triage

Mục đích: tạo CSV từ clean trace và suspect trace, sau đó xác định số CTU có `split_flag` bị thay đổi.

```bash
python3 tools/parse_ctu_trace.py evidence/ctu_clean_trace.log --csv report/clean_ctu.csv > report/clean_summary.txt
python3 tools/parse_ctu_trace.py evidence/ctu_suspect_trace.log --csv report/suspect_ctu.csv > report/suspect_summary.txt
python3 tools/evidence_triage.py report/clean_ctu.csv report/suspect_ctu.csv > report/evidence_triage.txt
cat report/evidence_triage.txt
```

Kết quả đúng:

```text
EVIDENCE_DIFF=split_flag_changes:8
```

### Nhiệm vụ 2 - spatial_anomaly_heatmap

Mục đích: biểu diễn vị trí các CTU bị thay đổi để đánh giá pattern carrier.

```bash
python3 tools/spatial_heatmap.py report/clean_ctu.csv report/suspect_ctu.csv > report/heatmap.txt
cat report/heatmap.txt
```

Kết quả đúng:

```text
HEATMAP_CHANGED=8
```

### Nhiệm vụ 3 - guided_anomaly_classification

Đọc evidence rồi tạo file phân loại:

```bash
cat evidence/case_note.txt
cat report/evidence_triage.txt
cat report/heatmap.txt
nano report/classification.txt
```

File cần thể hiện `REGION`, `RD_RISK`, `PSNR_RISK` và `VERDICT`. Sinh viên tự điền giá trị dựa trên bằng chứng.

```bash
python3 tools/classification_check.py report/classification.txt > report/classification_check.txt
cat report/classification_check.txt
```

Kết quả đúng:

```text
CLASSIFICATION_OK=targeted_carrier:medium_texture:low
```

### Nhiệm vụ 4 - carrier_order_recovery

Mục đích: xác định 32 carrier đầu tiên theo thứ tự decoder dùng để đọc payload.

```bash
python3 tools/carrier_order.py report/suspect_ctu.csv --out report/carrier_order.csv > report/carrier_order.txt
cat report/carrier_order.txt
head report/carrier_order.csv
```

Kết quả đúng:

```text
CARRIER_ORDER=32:frame_y_x
```

### Nhiệm vụ 5 - decoder_message_recovery

Mở extractor:

```bash
nano tools/extract_split.py
```

Tìm TODO của Task 5. Gợi ý: đọc `split_flag` của từng carrier trong `report/carrier_order.csv`; `0` tạo bit `0`, `1` tạo bit `1`; bỏ qua giá trị không hợp lệ.

```bash
python3 tools/extract_split.py report/suspect_ctu.csv report/carrier_order.csv > report/extracted.txt
cat report/extracted.txt
```

Kết quả đúng:

```text
EXTRACTED_MESSAGE=CTU3
```

### Nhiệm vụ 6 - incident_conclusion

Tạo báo cáo kết luận incident:

```bash
cat evidence/case_note.txt
cat report/extracted.txt
nano report/incident_answer.txt
python3 tools/answer_check.py report/incident_answer.txt report/extracted.txt evidence/case_note.txt > report/answer_check.txt
cat report/answer_check.txt
```

Báo cáo trả lời cần nêu đủ `message`, `technique`, `region` và `confidence`.

Kết quả đúng:

```text
ANSWER_OK=CTU3:CTU_SPLIT_FLAG:medium_texture
```

## 6. Checkwork

```bash
checkwork hevc-ctu-split-stego
```

Checkwork:

1. `evidence_triage`
2. `spatial_anomaly_heatmap`
3. `guided_anomaly_classification`
4. `carrier_order_recovery`
5. `decoder_message_recovery`
6. `incident_conclusion`
