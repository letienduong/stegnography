# Lab: hevc-ctu-split-stego

## 1. Giới thiệu

Bài này là một ca điều tra decoder-side: sinh viên nhận clean trace và suspect trace, phát hiện split pattern bất thường, dựng carrier path và tách thông điệp từ evidence nghi vấn. Không tự nhúng như bài intra.

## 2. Quy tắc

- `split_flag=0` -> bit `0`
- `split_flag=1` -> bit `1`
- Carrier path: CTU có `texture=medium`, RD gap <= `0.10`, lấy 32 CTU đầu theo scan order.

## 3. Tải và khởi động

```bash
curl -L https://github.com/letienduong/stegnography/raw/refs/heads/main/install-hevc-ctu-split-stego.sh | bash
labtainer -r hevc-ctu-split-stego
```

## 4. Nhiệm vụ

### Nhiệm vụ 1 - ctu_grid_snapshot

```bash
python3 tools/parse_ctu_trace.py evidence/ctu_clean_trace.log --csv report/clean_ctu.csv > report/clean_summary.txt
python3 tools/parse_ctu_trace.py evidence/ctu_suspect_trace.log --csv report/suspect_ctu.csv > report/suspect_summary.txt
python3 tools/ctu_grid.py report/suspect_ctu.csv --frame 0 > report/ctu_grid.txt
cat report/ctu_grid.txt
```

Kết quả: `CTU_GRID=5x4`.

### Nhiệm vụ 2 - spatial_split_anomaly

```bash
python3 tools/compare_split_maps.py report/clean_ctu.csv report/suspect_ctu.csv --out report/split_changes.csv > report/split_anomaly.txt
cat report/split_anomaly.txt
```

Kết quả: `CHANGED_CTUS=8`.

### Nhiệm vụ 3 - carrier_path_audit

```bash
python3 tools/carrier_path.py report/suspect_ctu.csv --bits 32 --out report/carrier_path.csv > report/carrier_path.txt
cat report/carrier_path.txt
```

Kết quả: `CARRIER_PATH=32`.

### Nhiệm vụ 4 - split_decoder_extractor

Sửa `tools/extract_split.py`, thay `pass` bằng:

```python
if row["split_flag"] == "0":
    bits.append("0")
elif row["split_flag"] == "1":
    bits.append("1")
```

Chạy:

```bash
python3 tools/extract_split.py report/suspect_ctu.csv report/carrier_path.csv > report/extracted.txt
cat report/extracted.txt
```

Kết quả: `EXTRACTED_MESSAGE=CTU3`.

### Nhiệm vụ 5 - case_conclusion_report

```bash
cat evidence/case_note.txt
nano answer.txt
```

Nội dung:

```text
CTU3 CTU_SPLIT_FLAG medium_texture
```

```bash
python3 tools/answer_check.py answer.txt report/extracted.txt evidence/case_note.txt > report/answer_check.txt
cat report/answer_check.txt
```

Kết quả: `ANSWER_OK=CTU3:CTU_SPLIT_FLAG:medium_texture`.

### Nhiệm vụ 6 - rd_psnr_impact_report

```bash
python3 tools/measure_impact.py report/clean_ctu.csv report/suspect_ctu.csv > report/impact.txt
python3 tools/final_check.py report/extracted.txt report/impact.txt > report/final_check.txt
cat report/final_check.txt
```

Kết quả: `FINAL_STATUS=CTU3:0.06`.

## 5. Checkwork

```bash
checkwork hevc-ctu-split-stego
```
