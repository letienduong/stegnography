#!/usr/bin/env python3
import argparse
import csv
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("suspect_csv", type=Path)
    parser.add_argument("--bits", type=int, default=32)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    with args.suspect_csv.open(newline="", encoding="ascii") as handle:
        rows = list(csv.DictReader(handle))

    carriers = []
    for row in rows:
        rd_keep = float(row["rd_keep"])
        rd_split = float(row["rd_split"])
        relative_gap = (rd_split - rd_keep) / rd_keep
        if row["texture"] == "medium" and relative_gap <= 0.10:
            item = dict(row)
            item["relative_gap"] = f"{relative_gap:.4f}"
            carriers.append(item)
            if len(carriers) >= args.bits:
                break

    args.out.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0].keys()) + ["relative_gap"]
    with args.out.open("w", newline="", encoding="ascii") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(carriers)

    print(f"CARRIER_PATH={len(carriers)}")
    print("CARRIER_REGION=medium_texture")
    print("CARRIER_RULE=scan_order:medium:epsilon0.10")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

