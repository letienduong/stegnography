#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path


def from_bits(bits: str) -> str:
    raw = bytes(int(bits[i : i + 8], 2) for i in range(0, len(bits), 8))
    return raw.decode("ascii")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("stego_csv", type=Path)
    args = parser.parse_args()

    with args.stego_csv.open(newline="", encoding="ascii") as handle:
        rows = list(csv.DictReader(handle))
    bits = []
    for row in rows:
        if not row.get("embed_bit"):
            continue
        if row["stego_split_flag"] == "0":
            bits.append("0")
        elif row["stego_split_flag"] == "1":
            bits.append("1")
    print(f"RECOVERED_BITS={len(bits)}")
    print(f"EXTRACTED_MESSAGE={from_bits(''.join(bits))}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
