#!/usr/bin/env python3
import argparse
import csv
from pathlib import Path


def from_bits(bits: str) -> str:
    raw = bytes(int(bits[i : i + 8], 2) for i in range(0, len(bits), 8))
    return raw.decode("ascii")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("stego_csv", type=Path)
    parser.add_argument("carrier_csv", type=Path, nargs="?")
    args = parser.parse_args()

    with args.stego_csv.open(newline="", encoding="ascii") as handle:
        all_rows = list(csv.DictReader(handle))
    if args.carrier_csv:
        with args.carrier_csv.open(newline="", encoding="ascii") as handle:
            carriers = list(csv.DictReader(handle))
        keys = {(row["frame"], row["ctu"], row["x"], row["y"]) for row in carriers}
        rows = [row for row in all_rows if (row["frame"], row["ctu"], row["x"], row["y"]) in keys]
    else:
        rows = [row for row in all_rows if row.get("embed_bit")]
    bits = []
    for row in rows:
        # TODO Task 5:
        # split_flag 0 -> recover bit 0
        # split_flag 1 -> recover bit 1
        # Ignore invalid flag values.
        pass
    print(f"RECOVERED_BITS={len(bits)}")
    print(f"EXTRACTED_MESSAGE={from_bits(''.join(bits))}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

