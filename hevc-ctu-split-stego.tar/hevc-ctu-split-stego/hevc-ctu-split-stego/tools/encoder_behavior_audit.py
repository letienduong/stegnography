#!/usr/bin/env python3
import argparse
import csv
from pathlib import Path


KEYS = ("frame", "ctu", "x", "y")


def load(path):
    with path.open(newline="", encoding="ascii") as handle:
        return {tuple(row[key] for key in KEYS): row for row in csv.DictReader(handle)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("clean_csv", type=Path)
    parser.add_argument("suspect_csv", type=Path)
    args = parser.parse_args()

    clean = load(args.clean_csv)
    suspect = load(args.suspect_csv)
    changed = []
    for key, row in suspect.items():
        if row["split_flag"] != clean[key]["split_flag"]:
            rd_keep = float(row["rd_keep"])
            rd_split = float(row["rd_split"])
            gap = (rd_split - rd_keep) / rd_keep
            changed.append((row, gap))

    medium = sum(1 for row, _ in changed if row["texture"] == "medium")
    low_gap = sum(1 for _, gap in changed if gap <= 0.10)
    low_psnr = sum(1 for row, _ in changed if float(row["psnr_drop_db"]) <= 0.06)
    verdict = "targeted_low_risk" if medium == len(changed) and low_gap == len(changed) and low_psnr == len(changed) else "inconclusive"
    print(f"ENCODER_AUDIT={verdict}")
    print(f"MEDIUM_TEXTURE_CHANGED={medium}")
    print(f"LOW_RD_GAP_CHANGED={low_gap}")
    print(f"LOW_PSNR_DROP_CHANGED={low_psnr}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
