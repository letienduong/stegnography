#!/usr/bin/env python3
import argparse
import csv
from collections import Counter
from pathlib import Path


KEYS = ("frame", "ctu", "x", "y")


def load(path):
    with path.open(newline="", encoding="ascii") as handle:
        return {tuple(row[key] for key in KEYS): row for row in csv.DictReader(handle)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("clean_csv", type=Path)
    parser.add_argument("suspect_csv", type=Path)
    args = parser.parse_args()

    clean = load(args.clean_csv)
    suspect = load(args.suspect_csv)
    changed = []
    frame_counts = Counter()
    for key, row in suspect.items():
        if row["split_flag"] != clean[key]["split_flag"]:
            changed.append(row)
            frame_counts[row["frame"]] += 1

    top_frame, top_count = frame_counts.most_common(1)[0]
    print(f"EVIDENCE_DIFF=split_flag_changes:{len(changed)}")
    print(f"TOP_FRAME={top_frame}:{top_count}")
    print(f"TRACE_PAIR=clean_vs_suspect")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
