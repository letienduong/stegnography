#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path


def read_policy(path: Path) -> dict[str, str]:
    policy = {}
    for line in path.read_text(encoding="ascii").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, value = line.split("=", 1)
        policy[key.strip()] = value.strip()
    return policy


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("policy", type=Path)
    parser.add_argument("candidates", type=Path)
    parser.add_argument("message", type=Path)
    args = parser.parse_args()
    policy = read_policy(args.policy)
    with args.candidates.open(newline="", encoding="ascii") as handle:
        capacity = sum(1 for _ in csv.DictReader(handle))
    message_bits = len(args.message.read_text(encoding="ascii").strip().encode("ascii")) * 8
    texture = policy.get("TEXTURE", "")
    epsilon = policy.get("EPSILON", "")
    min_capacity = int(policy.get("MIN_CAPACITY_BITS", "0"))
    ok = texture == "medium" and epsilon == "0.10" and capacity >= message_bits and capacity >= min_capacity
    print(f"CAPACITY_BITS={capacity}")
    print(f"MESSAGE_BITS={message_bits}")
    print(f"POLICY_OK={texture}:{epsilon}:{min_capacity}" if ok else "POLICY_OK=failed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
