#!/usr/bin/env python3
import argparse
from pathlib import Path


def read_kv(path):
    values = {}
    for line in path.read_text(encoding="ascii").splitlines():
        line = line.strip()
        if not line or line.startswith("#") or "=" not in line:
            continue
        key, value = line.split("=", 1)
        values[key.strip()] = value.strip()
    return values


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("classification", type=Path)
    args = parser.parse_args()

    values = read_kv(args.classification)
    ok = (
        values.get("REGION") == "medium_texture"
        and values.get("RD_RISK") == "low"
        and values.get("PSNR_RISK") == "low"
        and values.get("VERDICT") == "targeted_carrier"
    )
    print("CLASSIFICATION_OK=targeted_carrier:medium_texture:low" if ok else "CLASSIFICATION_OK=failed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
