#!/usr/bin/env python3
import argparse
import csv
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("original_csv", type=Path)
    parser.add_argument("stego_csv", type=Path)
    args = parser.parse_args()

    with args.original_csv.open(newline="", encoding="ascii") as handle:
        original = list(csv.DictReader(handle))
    with args.stego_csv.open(newline="", encoding="ascii") as handle:
        stego = list(csv.DictReader(handle))
    original_by_key = {(row["frame"], row["ctu"], row["x"], row["y"]): row for row in original}
    selected = {
        (row["frame"], row["ctu"], row["x"], row["y"])
        for row in stego
        if row.get("embed_bit")
        or row["split_flag"] != original_by_key[(row["frame"], row["ctu"], row["x"], row["y"])]["split_flag"]
    }

    bits_before = 0
    bits_after = 0
    drops = []
    for row in original:
        key = (row["frame"], row["ctu"], row["x"], row["y"])
        bits_before += int(row["bits_keep"])
        if key in selected:
            bits_after += int(row["bits_split"])
            drops.append(float(row["psnr_drop_db"]))
        else:
            bits_after += int(row["bits_keep"])
    delta = ((bits_after - bits_before) / bits_before) * 100.0
    psnr_drop = sum(drops) / len(drops)
    print(f"BITRATE_BEFORE={bits_before}")
    print(f"BITRATE_AFTER={bits_after}")
    print(f"BITRATE_DELTA_PERCENT={delta:.2f}")
    print(f"PSNR_DROP_DB={psnr_drop:.2f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

