#!/usr/bin/env python3
import argparse
import csv
from collections import Counter
from pathlib import Path


KEYS = ("frame", "ctu", "x", "y")


def load(path: Path):
    with path.open(newline="", encoding="ascii") as handle:
        return {tuple(row[key] for key in KEYS): row for row in csv.DictReader(handle)}


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("clean_csv", type=Path)
    parser.add_argument("suspect_csv", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    clean = load(args.clean_csv)
    suspect = load(args.suspect_csv)
    changed = []
    textures = Counter()
    for key, row in suspect.items():
        base = clean[key]
        if row["split_flag"] != base["split_flag"]:
            item = dict(row)
            item["clean_split_flag"] = base["split_flag"]
            item["suspect_split_flag"] = row["split_flag"]
            changed.append(item)
            textures[row["texture"]] += 1

    args.out.parent.mkdir(parents=True, exist_ok=True)
    fields = list(next(iter(suspect.values())).keys()) + ["clean_split_flag", "suspect_split_flag"]
    with args.out.open("w", newline="", encoding="ascii") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(changed)

    region = "medium_texture" if textures.get("medium", 0) == len(changed) else "mixed_texture"
    print(f"CHANGED_CTUS={len(changed)}")
    print(f"CHANGE_REGION={region}")
    print("SPLIT_PATTERN=suspect_differs_from_clean")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())


