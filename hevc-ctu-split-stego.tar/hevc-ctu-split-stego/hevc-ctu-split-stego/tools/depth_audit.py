#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from collections import Counter
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_in", type=Path)
    args = parser.parse_args()
    with args.csv_in.open(newline="", encoding="ascii") as handle:
        counts = Counter(row["depth"] for row in csv.DictReader(handle))
    for depth in sorted(counts, key=int):
        print(f"DEPTH_{depth}={counts[depth]}")
    print("DEPTH_PATTERN=" + ",".join(f"{depth}:{counts[depth]}" for depth in sorted(counts, key=int)))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
