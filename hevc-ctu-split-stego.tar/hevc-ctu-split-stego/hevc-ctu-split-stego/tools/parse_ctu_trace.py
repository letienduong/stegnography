#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path


FIELDS = [
    "frame",
    "ctu",
    "x",
    "y",
    "depth",
    "texture",
    "split_flag",
    "alt_split",
    "rd_keep",
    "rd_split",
    "bits_keep",
    "bits_split",
    "psnr_drop_db",
]


def parse_line(line: str) -> dict[str, str]:
    row = {}
    for part in line.split()[1:]:
        key, value = part.split("=", 1)
        row[key] = value
    return row


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("trace", type=Path)
    parser.add_argument("--csv", dest="csv_out", type=Path, required=True)
    args = parser.parse_args()

    rows = [parse_line(line) for line in args.trace.read_text(encoding="ascii").splitlines() if line.startswith("CTU ")]
    args.csv_out.parent.mkdir(parents=True, exist_ok=True)
    with args.csv_out.open("w", newline="", encoding="ascii") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    split_count = sum(1 for row in rows if row["split_flag"] == "1")
    print(f"TRACE_CTU_COUNT={len(rows)}")
    print(f"TRACE_SPLIT_COUNT={split_count}")
    print("MAX_CTU_SIZE=64")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
