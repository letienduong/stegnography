#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path


def to_bits(text: str) -> str:
    return "".join(f"{byte:08b}" for byte in text.encode("ascii"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("all_ctus", type=Path)
    parser.add_argument("candidates", type=Path)
    parser.add_argument("message", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    with args.all_ctus.open(newline="", encoding="ascii") as handle:
        rows = list(csv.DictReader(handle))
    with args.candidates.open(newline="", encoding="ascii") as handle:
        candidates = list(csv.DictReader(handle))
    bits = to_bits(args.message.read_text(encoding="ascii").strip())
    if len(bits) > len(candidates):
        raise SystemExit("message does not fit candidate set")

    candidate_keys = {(row["frame"], row["ctu"], row["x"], row["y"]) for row in candidates}
    embedded = 0
    for row in rows:
        key = (row["frame"], row["ctu"], row["x"], row["y"])
        if key not in candidate_keys or embedded >= len(bits):
            row["embed_bit"] = ""
            row["stego_split_flag"] = row["split_flag"]
            continue
        bit = bits[embedded]
        row["embed_bit"] = bit
        # TODO Task 4:
        # bit 0 -> force split_flag 0 (do not split this CU)
        # bit 1 -> force split_flag 1 (split this CU)
        # Replace the placeholder below with the correct split-flag mapping.
        row["stego_split_flag"] = "TODO"
        embedded += 1

    args.out.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(rows[0].keys())
    with args.out.open("w", newline="", encoding="ascii") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    split_ones = sum(1 for row in rows if row["stego_split_flag"] == "1")
    print(f"EMBEDDED_BITS={embedded}")
    print(f"EMBEDDED_CTUS={embedded}")
    print(f"STEGO_SPLIT_FLAG_1={split_ones}")
    print("BIT_MAPPING=split0:0,split1:1")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
