#!/usr/bin/env python3
import argparse
from pathlib import Path


def value_from(path: Path, key: str) -> str:
    for line in path.read_text(encoding="ascii").splitlines():
        if line.startswith(key + "="):
            return line.split("=", 1)[1].strip()
    raise SystemExit(f"missing {key} in {path}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("extracted", type=Path)
    parser.add_argument("impact", type=Path)
    args = parser.parse_args()
    message = value_from(args.extracted, "EXTRACTED_MESSAGE")
    psnr = value_from(args.impact, "PSNR_DROP_DB")
    print(f"FINAL_STATUS={message}:{psnr}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

