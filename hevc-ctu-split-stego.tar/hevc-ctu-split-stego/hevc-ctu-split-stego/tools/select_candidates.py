#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_in", type=Path)
    parser.add_argument("--epsilon", type=float, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    with args.csv_in.open(newline="", encoding="ascii") as handle:
        rows = list(csv.DictReader(handle))
    chosen = []
    for row in rows:
        rd_keep = float(row["rd_keep"])
        rd_split = float(row["rd_split"])
        relative_gap = (rd_split - rd_keep) / rd_keep
        if row["texture"] == "medium" and relative_gap <= args.epsilon:
            row["relative_gap"] = f"{relative_gap:.4f}"
            chosen.append(row)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0].keys()) + ["relative_gap"]
    with args.out.open("w", newline="", encoding="ascii") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(chosen)
    print(f"EPSILON={args.epsilon:.2f}")
    print(f"ELIGIBLE_CTUS={len(chosen)}")
    print("TEXTURE_POLICY=medium")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
