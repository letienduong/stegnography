#!/usr/bin/env python3
import argparse
from pathlib import Path


def value_from(path: Path, key: str) -> str:
    for line in path.read_text(encoding="ascii").splitlines():
        if line.startswith(key + "="):
            return line.split("=", 1)[1].strip()
    raise SystemExit(f"missing {key} in {path}")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("answer", type=Path)
    parser.add_argument("extracted", type=Path)
    parser.add_argument("case_note", type=Path)
    args = parser.parse_args()

    message = value_from(args.extracted, "EXTRACTED_MESSAGE")
    expected = {
        "message": message,
        "technique": value_from(args.case_note, "technique"),
        "region": value_from(args.case_note, "suspect_region"),
    }
    content = args.answer.read_text(encoding="ascii").strip()
    fields = {}
    if "=" in content:
        for line in content.splitlines():
            if "=" in line:
                key, value = line.split("=", 1)
                fields[key.strip()] = value.strip()
        ok = (
            fields.get("message") == expected["message"]
            and fields.get("technique") == expected["technique"]
            and fields.get("region") == expected["region"]
            and fields.get("confidence") == "high"
        )
    else:
        tokens = content.split()
        ok = len(tokens) >= 3 and tokens[0] == expected["message"] and tokens[1] == expected["technique"] and tokens[2] == expected["region"]
    print(
        f"ANSWER_OK={expected['message']}:{expected['technique']}:{expected['region']}"
        if ok
        else "ANSWER_OK=failed"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

