#!/usr/bin/env python3
import argparse
import csv
from pathlib import Path


KEYS = ("frame", "ctu", "x", "y")


def load(path):
    with path.open(newline="", encoding="ascii") as handle:
        return {tuple(row[key] for key in KEYS): row for row in csv.DictReader(handle)}


def normalize_lines(path):
    lines = []
    for raw in path.read_text(encoding="ascii").splitlines():
        line = raw.strip()
        if not line:
            continue
        if line.startswith("FRAME_"):
            lines.append(line)
        elif set(line.replace(" ", "")) <= {"X", "."}:
            lines.append(" ".join(line.split()))
    return lines


def expected_lines(clean_csv, suspect_csv):
    clean = load(clean_csv)
    suspect = load(suspect_csv)
    lines = []
    changed_total = 0
    frame_counts = {}
    frames = sorted({row["frame"] for row in suspect.values()}, key=int)
    for frame in frames:
        rows = [row for row in suspect.values() if row["frame"] == frame]
        rows.sort(key=lambda row: (int(row["y"]), int(row["x"])))
        lines.append(f"FRAME_{frame}_ANOMALY_MAP")
        frame_count = 0
        for y in sorted({int(row["y"]) for row in rows}):
            marks = []
            for row in [item for item in rows if int(item["y"]) == y]:
                key = tuple(row[k] for k in KEYS)
                mark = "X" if row["split_flag"] != clean[key]["split_flag"] else "."
                if mark == "X":
                    frame_count += 1
                marks.append(mark)
            lines.append(" ".join(marks))
        frame_counts[frame] = frame_count
        changed_total += frame_count
    return lines, frame_counts, changed_total


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("clean_csv", type=Path)
    parser.add_argument("suspect_csv", type=Path)
    parser.add_argument("manual_heatmap", type=Path)
    args = parser.parse_args()

    expected, frame_counts, total = expected_lines(args.clean_csv, args.suspect_csv)
    actual = normalize_lines(args.manual_heatmap)
    ok = actual == expected
    frame0 = frame_counts.get("0", 0)
    print(f"HEATMAP_OK=frame0:{frame0},total:{total}" if ok else "HEATMAP_OK=failed")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
