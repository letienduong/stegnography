#!/usr/bin/env python3
from pathlib import Path


def to_bits(text: str) -> str:
    return "".join(f"{byte:08b}" for byte in text.encode("ascii"))


def main() -> int:
    root = Path.cwd()
    evidence = root / "evidence"
    message = root / "message"
    evidence.mkdir(exist_ok=True)
    message.mkdir(exist_ok=True)

    header = [
        "# frame ctu x y depth texture split_flag alt_split rd_keep rd_split bits_keep bits_split psnr_drop_db"
    ]
    clean_lines = list(header)
    suspect_lines = list(header)
    secret = "CTU3"
    bits = to_bits(secret)
    for idx in range(80):
        frame = idx // 20
        ctu = idx % 20
        x = (ctu % 5) * 64
        y = (ctu // 5) * 64
        depth = idx % 3
        eligible = idx < 48
        texture = "medium" if eligible else ("flat" if idx % 2 == 0 else "complex")
        split_flag = idx % 2
        suspect_split_flag = split_flag
        embed_bit = ""
        if idx < len(bits):
            embed_bit = bits[idx]
            suspect_split_flag = int(embed_bit)
        alt_split = 1 - split_flag
        rd_keep = 200.0 + idx
        rd_gap = 0.07 if eligible else 0.18
        rd_split = rd_keep * (1.0 + rd_gap)
        bits_keep = 300 + idx
        bits_split = bits_keep + (3 if eligible else 18)
        psnr_drop = 0.06 if eligible else 0.24
        base = (
            f"CTU frame={frame} ctu={ctu} x={x} y={y} depth={depth} "
            f"texture={texture} split_flag={{split_flag}} alt_split={alt_split} "
            f"rd_keep={rd_keep:.2f} rd_split={rd_split:.2f} "
            f"bits_keep={bits_keep} bits_split={bits_split} psnr_drop_db={psnr_drop:.2f}"
        )
        clean_lines.append(base.format(split_flag=split_flag))
        suspect_lines.append(base.format(split_flag=suspect_split_flag) + (f" embed_bit={embed_bit}" if embed_bit else ""))

    (evidence / "ctu_split_trace.log").write_text("\n".join(suspect_lines) + "\n", encoding="ascii")
    (evidence / "ctu_clean_trace.log").write_text("\n".join(clean_lines) + "\n", encoding="ascii")
    (evidence / "ctu_suspect_trace.log").write_text("\n".join(suspect_lines) + "\n", encoding="ascii")
    (evidence / "case_note.txt").write_text(
        "case=warehouse_camera\nsuspect_region=medium_texture\ntechnique=CTU_SPLIT_FLAG\n",
        encoding="ascii",
    )
    (message / "secret.txt").write_text(secret + "\n", encoding="ascii")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

