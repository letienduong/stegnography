#!/usr/bin/env python3
import argparse
import csv
from pathlib import Path


KEYS = ("frame", "ctu", "x", "y")


def load(path):
    with path.open(newline="", encoding="ascii") as handle:
        return {tuple(row[key] for key in KEYS): row for row in csv.DictReader(handle)}


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("clean_csv", type=Path)
    parser.add_argument("suspect_csv", type=Path)
    parser.add_argument("--frame")
    args = parser.parse_args()

    clean = load(args.clean_csv)
    suspect = load(args.suspect_csv)
    marks = []
    frames = [args.frame] if args.frame is not None else sorted({row["frame"] for row in suspect.values()}, key=int)
    for frame in frames:
        rows = [row for row in suspect.values() if row["frame"] == frame]
        rows.sort(key=lambda row: (int(row["y"]), int(row["x"])))
        print(f"FRAME_{frame}_ANOMALY_MAP")
        for y in sorted({int(row["y"]) for row in rows}):
            line = []
            for row in [item for item in rows if int(item["y"]) == y]:
                key = tuple(row[k] for k in KEYS)
                line.append("X" if row["split_flag"] != clean[key]["split_flag"] else ".")
            print(" ".join(line))
            marks.extend(line)
    print(f"HEATMAP_CHANGED={marks.count('X')}")
    print("HEATMAP_SYMBOLS=X:changed,.:same")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
