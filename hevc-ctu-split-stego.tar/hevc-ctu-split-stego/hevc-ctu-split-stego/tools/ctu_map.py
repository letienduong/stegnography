#!/usr/bin/env python3
import argparse
import csv
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_in", type=Path)
    args = parser.parse_args()

    with args.csv_in.open(newline="", encoding="ascii") as handle:
        rows = list(csv.DictReader(handle))
    print("frame ctu x y depth split texture")
    for row in rows:
        print(
            f"{row['frame']} {row['ctu']} {row['x']} {row['y']} "
            f"{row['depth']} {row['split_flag']} {row['texture']}"
        )
    print(f"MAP_ROWS={len(rows)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

