#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_in", type=Path)
    parser.add_argument("--column", default="split_flag")
    args = parser.parse_args()

    with args.csv_in.open(newline="", encoding="ascii") as handle:
        rows = list(csv.DictReader(handle))
    zero = sum(1 for row in rows if row[args.column] == "0")
    one = sum(1 for row in rows if row[args.column] == "1")
    print(f"COLUMN={args.column}")
    print(f"SPLIT_FLAG_0={zero}")
    print(f"SPLIT_FLAG_1={one}")
    print(f"TOTAL_FLAGS={zero + one}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
