#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_in", type=Path)
    parser.add_argument("--frame", default="0")
    args = parser.parse_args()

    with args.csv_in.open(newline="", encoding="ascii") as handle:
        rows = [row for row in csv.DictReader(handle) if row["frame"] == args.frame]
    rows.sort(key=lambda row: (int(row["y"]), int(row["x"])))
    print(f"GRID_FRAME={args.frame}")
    for y in sorted({int(row["y"]) for row in rows}):
        cells = []
        for row in [item for item in rows if int(item["y"]) == y]:
            cells.append(f"D{row['depth']}S{row['split_flag']}")
        print(" ".join(cells))
    print("CTU_GRID=5x4")
    print(f"GRID_CTUS={len(rows)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
