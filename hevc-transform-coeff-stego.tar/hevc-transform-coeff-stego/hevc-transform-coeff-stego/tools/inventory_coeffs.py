#!/usr/bin/env python3
import csv
from collections import Counter
from pathlib import Path

BASE = Path("/home/ubuntu")
TRACE = BASE / "evidence" / "transform_coeff_trace.csv"


def main():
    counts = Counter()
    texture_ac = Counter()
    with TRACE.open(newline="") as f:
        for row in csv.DictReader(f):
            level = int(row["level"])
            if row["freq_band"] == "dc":
                counts["dc"] += 1
            elif level == 0:
                counts["ac_zero"] += 1
            else:
                counts["ac_nonzero"] += 1
                texture_ac[row["texture"]] += 1

    out = BASE / "report" / "inventory.txt"
    out.write_text(
        "\n".join(
            [
                f"INVENTORY=dc:{counts['dc']},ac_nonzero:{counts['ac_nonzero']},ac_zero:{counts['ac_zero']}",
                f"AC_TEXTURE=low:{texture_ac['low']},medium:{texture_ac['medium']},high:{texture_ac['high']}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    print(out.read_text(encoding="utf-8"), end="")


if __name__ == "__main__":
    main()
