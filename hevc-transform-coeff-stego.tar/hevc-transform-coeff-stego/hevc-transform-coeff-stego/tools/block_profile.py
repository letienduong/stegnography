#!/usr/bin/env python3
import argparse
import csv
from pathlib import Path

BASE = Path("/home/ubuntu")
TRACE = BASE / "evidence" / "transform_coeff_trace.csv"


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--block", type=int, default=7)
    args = parser.parse_args()

    with TRACE.open(newline="") as f:
        rows = [row for row in csv.DictReader(f) if int(row["block_id"]) == args.block]

    if not rows:
        raise SystemExit(f"block {args.block} not found")

    dc = next(int(row["level"]) for row in rows if row["freq_band"] == "dc")
    nonzero_ac = sum(1 for row in rows if row["freq_band"] == "ac" and int(row["level"]) != 0)
    coeff_line = " ".join(
        f"c{row['coeff_index']}={row['level']}" for row in sorted(rows, key=lambda r: int(r["coeff_index"]))
    )
    out = BASE / "report" / "block_profile.txt"
    out.write_text(
        "\n".join(
            [
                f"BLOCK_PROFILE=block:{args.block},dc:{dc},nonzero_ac:{nonzero_ac}",
                f"COEFF_VECTOR={coeff_line}",
                "NOTE=DC is not used for hiding; AC coefficients carry parity bits.",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    print(out.read_text(encoding="utf-8"), end="")


if __name__ == "__main__":
    main()
