#!/usr/bin/env python3
from pathlib import Path

BASE = Path("/home/ubuntu")


def value(path, key):
    for line in path.read_text(encoding="utf-8").splitlines():
        if line.startswith(key + "="):
            return line.split("=", 1)[1]
    return ""


def main():
    message = value(BASE / "report" / "extracted.txt", "EXTRACTED_MESSAGE")
    psnr = value(BASE / "report" / "impact.txt", "PSNR_DROP_DB")
    out = BASE / "report" / "final_check.txt"
    out.write_text(f"FINAL_STATUS={message}:{psnr}\n", encoding="utf-8")
    print(out.read_text(encoding="utf-8"), end="")


if __name__ == "__main__":
    main()
