#!/usr/bin/env python3
import csv
from pathlib import Path

BASE = Path("/home/ubuntu")
TRACE = BASE / "evidence" / "transform_coeff_trace.csv"
OUT = BASE / "work" / "safe_coeffs.csv"


def safe(row):
    return (
        row["freq_band"] == "ac"
        and row["texture"] == "medium"
        and int(row["level"]) != 0
        and abs(int(row["level"])) <= 6
        and float(row["rd_margin"]) <= 0.10
    )


def main():
    OUT.parent.mkdir(exist_ok=True)
    with TRACE.open(newline="") as f:
        rows = [row for row in csv.DictReader(f) if safe(row)]
        fieldnames = rows[0].keys()

    with OUT.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    preview = rows[:5]
    report = BASE / "report" / "candidates.txt"
    report.write_text(
        "\n".join(
            [
                f"SAFE_COEFFS={len(rows)}",
                "RULE=freq_band=ac,texture=medium,abs(level)<=6,rd_margin<=0.10",
                "PREVIEW="
                + ",".join(
                    f"b{row['block_id']}:c{row['coeff_index']}:{row['level']}"
                    for row in preview
                ),
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    print(report.read_text(encoding="utf-8"), end="")


if __name__ == "__main__":
    main()
