#!/usr/bin/env python3
import csv
from pathlib import Path

BASE = Path("/home/ubuntu")


def main():
    evidence = BASE / "evidence"
    message = BASE / "message"
    report = BASE / "report"
    evidence.mkdir(exist_ok=True)
    message.mkdir(exist_ok=True)
    report.mkdir(exist_ok=True)

    trace_path = evidence / "transform_coeff_trace.csv"
    fields = [
        "frame",
        "block_id",
        "coeff_index",
        "scan_pos",
        "level",
        "freq_band",
        "texture",
        "rd_margin",
    ]
    textures = ["low", "medium", "high"]
    rows = []
    for block_id in range(40):
        texture = textures[block_id % 3]
        for coeff_index in range(8):
            if coeff_index == 0:
                level = 8 + (block_id % 5)
                freq_band = "dc"
            else:
                freq_band = "ac"
                if (block_id + coeff_index) % 7 == 0:
                    level = 0
                else:
                    mag = ((block_id * 3 + coeff_index * 2) % 6) + 1
                    level = mag if (block_id + coeff_index) % 2 == 0 else -mag
            if texture == "medium" and coeff_index != 0 and level != 0:
                rd_margin = 0.04 + ((block_id + coeff_index) % 6) * 0.01
            else:
                rd_margin = 0.14 + ((block_id + coeff_index) % 5) * 0.02
            rows.append(
                {
                    "frame": 0,
                    "block_id": block_id,
                    "coeff_index": coeff_index,
                    "scan_pos": coeff_index,
                    "level": level,
                    "freq_band": freq_band,
                    "texture": texture,
                    "rd_margin": f"{rd_margin:.2f}",
                }
            )

    with trace_path.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)

    (message / "secret.txt").write_text("QTC4\n", encoding="utf-8")
    (BASE / "policy.txt").write_text(
        "COEFF_DOMAIN=AC\nMAX_LEVEL_DELTA=1\nMIN_CAPACITY_BITS=32\n",
        encoding="utf-8",
    )
    print(f"WROTE={trace_path}")


if __name__ == "__main__":
    main()
