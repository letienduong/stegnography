#!/usr/bin/env python3
import csv
from pathlib import Path

BASE = Path("/home/ubuntu")
WHITELIST = BASE / "work" / "whitelist.csv"
MANIFEST = BASE / "work" / "payload_schedule.csv"


def text_to_bits(text):
    return "".join(f"{ord(ch):08b}" for ch in text)


def main():
    message = (BASE / "message" / "secret.txt").read_text(encoding="utf-8").strip()
    bits = text_to_bits(message)
    with WHITELIST.open(newline="") as f:
        slots = list(csv.DictReader(f))[: len(bits)]

    with MANIFEST.open("w", newline="") as f:
        fieldnames = ["bit_index", "bit", "block_id", "coeff_index", "source_level"]
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        for index, (bit, slot) in enumerate(zip(bits, slots)):
            writer.writerow(
                {
                    "bit_index": index,
                    "bit": bit,
                    "block_id": slot["block_id"],
                    "coeff_index": slot["coeff_index"],
                    "source_level": slot["level"],
                }
            )

    out = BASE / "report" / "payload_manifest.txt"
    out.write_text(
        "\n".join(
            [
                f"PAYLOAD_MANIFEST=message:{message},bits:{len(bits)},slots:{len(slots)}",
                f"FIRST_BYTE={bits[:8]}",
                f"LAST_SLOT=block:{slots[-1]['block_id']},coeff:{slots[-1]['coeff_index']}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    print(out.read_text(encoding="utf-8"), end="")


if __name__ == "__main__":
    main()
