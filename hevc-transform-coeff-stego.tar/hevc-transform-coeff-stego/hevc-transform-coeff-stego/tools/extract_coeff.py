#!/usr/bin/env python3
import csv
from pathlib import Path

BASE = Path("/home/ubuntu")
STEGO = BASE / "work" / "stego_coeff_trace.csv"


def bits_to_text(bits):
    chars = []
    for i in range(0, len(bits), 8):
        byte = bits[i : i + 8]
        if len(byte) == 8:
            chars.append(chr(int(byte, 2)))
    return "".join(chars)


def main():
    bits = []
    with STEGO.open(newline="") as f:
        for row in csv.DictReader(f):
            if row["embedded_bit"] == "":
                continue
            level = int(row["stego_level"])
            # TODO Task 5:
            # Recover one hidden bit from the parity of abs(stego_level).
            # Even magnitude means bit 0, odd magnitude means bit 1.
            pass

    message = bits_to_text("".join(bits))
    out = BASE / "report" / "extracted.txt"
    out.write_text(f"EXTRACTED_MESSAGE={message}\nBITS_READ={len(bits)}\n", encoding="utf-8")
    print(out.read_text(encoding="utf-8"), end="")


if __name__ == "__main__":
    main()
