#!/usr/bin/env python3
import hashlib
from pathlib import Path

BASE = Path("/home/ubuntu")
EVIDENCE = BASE / "evidence"


def sha256(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()


def is_annex_b_hevc(path):
    data = path.read_bytes()
    return data.startswith(b"\x00\x00\x00\x01") and b"HEVC" in data[:64]


def main():
    clean = EVIDENCE / "warehouse-clean.hevc"
    suspect = EVIDENCE / "warehouse-suspect.hevc"
    log = (EVIDENCE / "export_audit.log").read_text(encoding="utf-8")
    user = "unknown"
    for line in log.splitlines():
        if "action=uploaded" in line and "warehouse-suspect.hevc" in line:
            for token in line.split():
                if token.startswith("user="):
                    user = token.split("=", 1)[1]

    clean_sha = sha256(clean)
    suspect_sha = sha256(suspect)
    hash_diff = "yes" if clean_sha != suspect_sha else "no"
    codec_ok = "hevc" if is_annex_b_hevc(suspect) else "unknown"

    out = BASE / "report" / "evidence_intake.txt"
    out.write_text(
        "\n".join(
            [
                f"EVIDENCE_CASE=codec:{codec_ok},hash_diff:{hash_diff},user:{user}",
                f"CLEAN_SHA256={clean_sha}",
                f"SUSPECT_SHA256={suspect_sha}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    print(out.read_text(encoding="utf-8"), end="")


if __name__ == "__main__":
    main()
