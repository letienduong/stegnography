#!/usr/bin/env python3
import csv
from pathlib import Path

BASE = Path("/home/ubuntu")
TRACE = BASE / "evidence" / "transform_coeff_trace.csv"


def main():
    blocks = set()
    nonzero_ac = 0
    by_band = {"dc": 0, "ac": 0}
    with TRACE.open(newline="") as f:
        for row in csv.DictReader(f):
            blocks.add(row["block_id"])
            band = row["freq_band"]
            if int(row["level"]) != 0:
                by_band[band] += 1
            if band == "ac" and int(row["level"]) != 0:
                nonzero_ac += 1

    out = BASE / "report" / "coeff_scan.txt"
    out.write_text(
        "\n".join(
            [
                f"COEFF_SCAN=blocks:{len(blocks)},nonzero_ac:{nonzero_ac}",
                f"NONZERO_DC={by_band['dc']}",
                f"NONZERO_AC={by_band['ac']}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    print(out.read_text(encoding="utf-8"), end="")


if __name__ == "__main__":
    main()
