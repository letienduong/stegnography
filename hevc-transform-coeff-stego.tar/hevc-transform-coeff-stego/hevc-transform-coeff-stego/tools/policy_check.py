#!/usr/bin/env python3
import csv
from pathlib import Path

BASE = Path("/home/ubuntu")


def read_policy(path):
    policy = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        key, value = line.split("=", 1)
        policy[key.strip()] = value.strip()
    return policy


def main():
    policy = read_policy(BASE / "policy.txt")
    with (BASE / "work" / "safe_coeffs.csv").open(newline="") as f:
        capacity = sum(1 for _ in csv.DictReader(f))

    domain = policy.get("COEFF_DOMAIN")
    max_delta = policy.get("MAX_LEVEL_DELTA")
    min_capacity = int(policy.get("MIN_CAPACITY_BITS", "0"))
    ok = domain == "AC" and max_delta == "1" and capacity >= min_capacity
    out = BASE / "report" / "policy_check.txt"
    if ok:
        text = f"PARITY_POLICY_OK={domain}:{max_delta}:{min_capacity}\nCAPACITY_BITS={capacity}\n"
    else:
        text = (
            "PARITY_POLICY_FAIL\n"
            f"DOMAIN={domain}\nMAX_LEVEL_DELTA={max_delta}\n"
            f"MIN_CAPACITY_BITS={min_capacity}\nCAPACITY_BITS={capacity}\n"
        )
    out.write_text(text, encoding="utf-8")
    print(text, end="")
    raise SystemExit(0 if ok else 1)


if __name__ == "__main__":
    main()
