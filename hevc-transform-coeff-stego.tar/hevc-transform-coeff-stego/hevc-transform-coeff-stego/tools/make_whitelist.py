#!/usr/bin/env python3
import csv
from pathlib import Path

BASE = Path("/home/ubuntu")
TRACE = BASE / "evidence" / "transform_coeff_trace.csv"
OUT = BASE / "work" / "whitelist.csv"


def safe(row):
    return (
        row["freq_band"] == "ac"
        and row["texture"] == "medium"
        and int(row["level"]) != 0
        and abs(int(row["level"])) <= 6
        and float(row["rd_margin"]) <= 0.10
    )


def main():
    OUT.parent.mkdir(exist_ok=True)
    with TRACE.open(newline="") as f:
        rows = [row for row in csv.DictReader(f) if safe(row)]
        fieldnames = rows[0].keys()

    with OUT.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    capacity_ok = "yes" if len(rows) >= 32 else "no"
    out = BASE / "report" / "whitelist_audit.txt"
    out.write_text(
        "\n".join(
            [
                f"WHITELIST=medium_ac:{len(rows)},capacity_ok:{capacity_ok}",
                "FILTER=band:AC,texture:medium,max_delta:1,rd_margin<=0.10",
                f"FIRST_SLOT=block:{rows[0]['block_id']},coeff:{rows[0]['coeff_index']}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    print(out.read_text(encoding="utf-8"), end="")


if __name__ == "__main__":
    main()
