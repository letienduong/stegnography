#!/usr/bin/env python3
import csv
from pathlib import Path

BASE = Path("/home/ubuntu")
TRACE = BASE / "evidence" / "transform_coeff_trace.csv"
SCHEDULE = BASE / "work" / "payload_schedule.csv"
OUT = BASE / "work" / "stego_coeff_trace.csv"


def adjust_parity(level, bit):
    mag = abs(level)
    sign = 1 if level > 0 else -1
    wanted = int(bit)
    # TODO Task 4:
    # Return a coefficient level whose absolute-value parity equals wanted.
    # Keep the sign unchanged and change the magnitude by at most 1.
    return level


def main():
    with SCHEDULE.open(newline="") as f:
        schedule = list(csv.DictReader(f))
    bit_by_key = {
        (row["block_id"], row["coeff_index"]): row["bit"] for row in schedule
    }

    changed = 0
    embedded = 0
    odd_embedded = 0
    with TRACE.open(newline="") as f:
        reader = csv.DictReader(f)
        fieldnames = reader.fieldnames + ["stego_level", "embedded_bit"]
        rows = []
        for row in reader:
            key = (row["block_id"], row["coeff_index"])
            original = int(row["level"])
            if key in bit_by_key:
                bit = bit_by_key[key]
                stego = adjust_parity(original, bit)
                row["embedded_bit"] = bit
                embedded += 1
                if abs(stego) % 2 == 1:
                    odd_embedded += 1
                if stego != original:
                    changed += 1
            else:
                stego = original
                row["embedded_bit"] = ""
            row["stego_level"] = str(stego)
            rows.append(row)

    with OUT.open("w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)

    report = BASE / "report" / "embed_summary.txt"
    report.write_text(
        "\n".join(
            [
                f"EMBEDDED_BITS={embedded}",
                f"ODD_EMBEDDED_COEFFS={odd_embedded}",
                f"CHANGED_LEVELS={changed}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    print(report.read_text(encoding="utf-8"), end="")


if __name__ == "__main__":
    main()
