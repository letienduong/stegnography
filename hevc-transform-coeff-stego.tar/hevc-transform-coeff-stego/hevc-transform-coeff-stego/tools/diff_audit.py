#!/usr/bin/env python3
import csv
from pathlib import Path

BASE = Path("/home/ubuntu")
STEGO = BASE / "work" / "stego_coeff_trace.csv"


def main():
    changed = 0
    max_delta = 0
    odd_embedded = 0
    with STEGO.open(newline="") as f:
        for row in csv.DictReader(f):
            original = int(row["level"])
            stego = int(row["stego_level"])
            delta = abs(stego - original)
            if delta:
                changed += 1
            max_delta = max(max_delta, delta)
            if row["embedded_bit"] and abs(stego) % 2 == 1:
                odd_embedded += 1

    out = BASE / "report" / "diff_audit.txt"
    out.write_text(
        "\n".join(
            [
                f"STEGO_DIFF_OK=changed:{changed},max_delta:{max_delta}",
                f"ODD_EMBEDDED_COEFFS={odd_embedded}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    print(out.read_text(encoding="utf-8"), end="")


if __name__ == "__main__":
    main()
