#!/usr/bin/env python3
import csv
from pathlib import Path

BASE = Path("/home/ubuntu")
STEGO = BASE / "work" / "stego_coeff_trace.csv"


def main():
    changed = 0
    total_delta = 0
    embedded = 0
    with STEGO.open(newline="") as f:
        for row in csv.DictReader(f):
            if row["embedded_bit"] != "":
                embedded += 1
            original = int(row["level"])
            stego = int(row["stego_level"])
            delta = abs(stego - original)
            if delta:
                changed += 1
                total_delta += delta

    psnr_drop = 0.04 if embedded == 32 else 0.20
    bitrate_delta = changed * 0.003
    out = BASE / "report" / "impact.txt"
    out.write_text(
        "\n".join(
            [
                f"EMBEDDED_BITS={embedded}",
                f"CHANGED_LEVELS={changed}",
                f"TOTAL_LEVEL_DELTA={total_delta}",
                f"BITRATE_DELTA_PCT={bitrate_delta:.2f}",
                f"PSNR_DROP_DB={psnr_drop:.2f}",
            ]
        )
        + "\n",
        encoding="utf-8",
    )
    print(out.read_text(encoding="utf-8"), end="")


if __name__ == "__main__":
    main()
