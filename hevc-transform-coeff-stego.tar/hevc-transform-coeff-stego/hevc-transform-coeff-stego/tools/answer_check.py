#!/usr/bin/env python3
from pathlib import Path

BASE = Path("/home/ubuntu")
ANSWER = BASE / "answer.txt"


def main():
    text = ANSWER.read_text(encoding="utf-8").strip() if ANSWER.exists() else ""
    required = ["ops-video12", "QTC4", "TRANSFORM_COEFF_PARITY"]
    ok = all(item in text for item in required)
    out = BASE / "report" / "answer_check.txt"
    if ok:
        out.write_text("ANSWER_OK=ops-video12:QTC4:TRANSFORM_COEFF_PARITY\n", encoding="utf-8")
    else:
        out.write_text(f"ANSWER_FAIL={text}\n", encoding="utf-8")
    print(out.read_text(encoding="utf-8"), end="")
    raise SystemExit(0 if ok else 1)


if __name__ == "__main__":
    main()
