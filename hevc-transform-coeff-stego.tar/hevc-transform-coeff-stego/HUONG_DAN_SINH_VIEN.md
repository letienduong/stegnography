# Lab: hevc-transform-coeff-stego

## 1. Muc tieu

Bai lab nay giup sinh vien hieu cach H.265/HEVC bieu dien du lieu anh sau bien doi va luong tu hoa. Thay vi sua pixel truc tiep, bai lab giau tin vao parity cua he so bien doi luong tu hoa trong mien nen.

Sau khi hoan thanh, sinh vien can lam duoc:

- Doc trace he so transform coefficient cua cac block.
- Phan biet he so DC va AC.
- Chon he so AC an toan de giau tin.
- Nhung bit bang parity cua `abs(level)`.
- Tach lai thong diep tu parity.
- Danh gia tac dong den bitrate va PSNR.

## 2. Ly thuyet ngan

Trong H.265, residual cua block duoc bien doi va luong tu hoa thanh cac he so. He so DC bieu dien thanh phan trung binh, con he so AC bieu dien chi tiet tan so cao hon. Khi sua nhe mot so he so AC co bien do nho, tac dong thi giac thuong thap hon so voi sua he so DC.

Trong lab nay, bit duoc nhung bang parity:

- `abs(level)` chan bieu dien bit `0`.
- `abs(level)` le bieu dien bit `1`.

Vi du: `level = -4` mang bit `0`, `level = 5` mang bit `1`. Neu can doi bit, chi tang/giam bien do 1 don vi va giu nguyen dau cua he so.

## 3. Chuan bi

Mo terminal trong container lab:

```bash
cd /home/ubuntu
ls
```

Du lieu ban dau nam trong:

- `evidence/transform_coeff_trace.csv`: trace he so luong tu hoa.
- `message/secret.txt`: thong diep can giau.
- `policy.txt`: chinh sach chon he so.
- `tools/`: cac cong cu phan tich, nhung va tach tin.
- `report/`: noi sinh ra file de checkwork cham diem.

## 4. Nhiem vu 1 - Quet trace he so

Chay:

```bash
python3 tools/scan_coeffs.py
cat report/coeff_scan.txt
```

Ket qua dung can co:

```text
COEFF_SCAN=blocks:40,nonzero_ac:240
```

Y nghia: trace co 40 block va 240 he so AC khac 0 co the xem xet.

## 5. Nhiem vu 2 - Chon he so an toan

Xem nhanh trace:

```bash
head evidence/transform_coeff_trace.csv
```

Chon danh sach he so AC co texture trung binh va bien do nho:

```bash
python3 tools/select_coeffs.py
head work/safe_coeffs.csv
cat report/candidates.txt
```

Ket qua dung can co:

```text
SAFE_COEFFS=78
```

## 6. Nhiem vu 3 - Kiem tra policy

Mo file policy:

```bash
nano policy.txt
```

Noi dung hop le:

```text
COEFF_DOMAIN=AC
MAX_LEVEL_DELTA=1
MIN_CAPACITY_BITS=32
```

Kiem tra:

```bash
python3 tools/policy_check.py
cat report/policy_check.txt
```

Ket qua dung:

```text
PARITY_POLICY_OK=AC:1:32
```

## 7. Nhiem vu 4 - Hoan thien bo nhung

Mo file:

```bash
nano tools/embed_coeff.py
```

Tim ham `adjust_parity`. Thay phan `TODO Task 4` bang logic:

```python
if mag % 2 == wanted:
    return level
if mag == 0:
    return sign
return sign * (mag + 1)
```

Chay:

```bash
python3 tools/embed_coeff.py
cat report/embed_summary.txt
```

Ket qua dung can co:

```text
EMBEDDED_BITS=32
ODD_EMBEDDED_COEFFS=12
```

## 8. Nhiem vu 5 - Hoan thien bo tach tin

Mo file:

```bash
nano tools/extract_coeff.py
```

Tim `TODO Task 5` va them logic:

```python
bits.append(str(abs(level) % 2))
```

Chay:

```bash
python3 tools/extract_coeff.py
cat report/extracted.txt
```

Ket qua dung:

```text
EXTRACTED_MESSAGE=QTC4
```

## 9. Nhiem vu 6 - Do tac dong

Chay:

```bash
python3 tools/measure_impact.py
python3 tools/final_check.py
cat report/impact.txt
cat report/final_check.txt
```

Ket qua dung:

```text
FINAL_STATUS=QTC4:0.04
```

Gia tri `0.04` la muc giam PSNR mo phong trong trace cua lab. Muc nay nho vi moi he so chi duoc doi toi da 1 don vi.

## 10. Checkwork

Sau khi lam xong cac nhiem vu, chay checkwork cua Labtainer:

```bash
checkwork
```

Lab co 6 checkwork:

1. `coeff_scan_summary`
2. `safe_coeff_candidate_map`
3. `parity_policy_capacity`
4. `coeff_parity_embedding`
5. `coeff_parity_extractor`
6. `coeff_impact_report`

Neu task nao sai, xem lai file tuong ung trong thu muc `report/`.
