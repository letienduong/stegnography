# Lab: hevc-transform-coeff-stego

## 1. Gioi thieu

Ten lab: `hevc-transform-coeff-stego`

Chu de: dieu tra video H.265 nghi bi dung lam kenh giau tin trong he so bien doi luong tu hoa.

Vai tro cua sinh vien: analyst trong nhom SOC cua he thong kho hang. Nhom SOC phat hien mot file camera H.265 duoc export ra ngoai. Video nhin binh thuong, nhung trace codec cho thay co dau hieu carrier trong cac he so AC.

Muc tieu:

- Kiem tra clean/suspect evidence va log export.
- Hieu DC/AC coefficient trong transform block H.265.
- Tao whitelist he so AC an toan.
- Lap payload schedule truoc khi nhung.
- Sua embedder/extractor de giau va tach tin bang parity.
- Viet ket luan dieu tra trong `answer.txt`.

## 2. Kien thuc can nam

Trong H.265, residual cua block duoc bien doi va luong tu hoa thanh cac he so `level`.

- DC coefficient nam o vi tri dau, dai dien cho thanh phan trung binh.
- AC coefficient nam o cac vi tri sau, dai dien cho chi tiet tan so cao hon.

Bai lab chi dung AC coefficient lam carrier. Quy tac tach bit:

- `abs(level)` chan -> bit `0`.
- `abs(level)` le -> bit `1`.

Khi nhung, chi duoc doi bien do he so toi da 1 don vi va giu nguyen dau.

## 3. Du lieu trong lab

Vao thu muc lam bai:

```bash
cd /home/ubuntu
ls
```

Thu muc quan trong:

- `evidence/warehouse-clean.hevc`: video doi chieu.
- `evidence/warehouse-suspect.hevc`: video nghi van.
- `evidence/export_audit.log`: log export video.
- `evidence/transform_coeff_trace.csv`: trace he so transform.
- `message/secret.txt`: thong diep dung trong mo phong nhung.
- `tools/`: cong cu phan tich va tach tin.
- `report/`: noi luu ket qua checkwork.

## 4. Tai va khoi dong Lab

Cach khuyen nghi: chay script cai dat de tu tai lab va kiem tra moi truong checkwork:

```bash
curl -L https://github.com/letienduong/stegnography/raw/refs/heads/main/install-hevc-transform-coeff-stego.sh | bash
```

Hoac tai lab thu cong bang mot trong hai cach sau:

```bash
imodule https://github.com/letienduong/stegnography/raw/refs/heads/main/hevc-transform-coeff-stego.tar
```

Hoac dung `curl` neu khong dung `imodule`:

```bash
curl -L https://github.com/letienduong/stegnography/raw/refs/heads/main/hevc-transform-coeff-stego.tar | tar -x -C ~/labtainer/trunk/labs/
```

Khoi dong lab:

```bash
labtainer -r hevc-transform-coeff-stego
```

Neu Labtainer yeu cau cap nhat, chay `update-labtainer.sh`, sau do chay lai lenh khoi dong lab.

## 5. Nhiem vu 1 - Intake evidence

Muc dich: xac nhan file nghi van khac file sach, van co dau hieu H.265/Annex B, va tim user lien quan trong log.

Chay:

```bash
ls evidence
sha256sum evidence/warehouse-clean.hevc evidence/warehouse-suspect.hevc
cat evidence/export_audit.log
python3 tools/evidence_intake.py
cat report/evidence_intake.txt
```

Ket qua dung:

```text
EVIDENCE_CASE=codec:hevc,hash_diff:yes,user:ops-video12
```

## 6. Nhiem vu 2 - Khao sat transform block

Muc dich: nhin vao mot block cu the de thay DC va AC coefficient.

```bash
python3 tools/block_profile.py --block 7
cat report/block_profile.txt
```

Ket qua dung:

```text
BLOCK_PROFILE=block:7,dc:10,nonzero_ac:6
```

Doc dong `COEFF_VECTOR`. Khong dung DC de giau tin trong bai nay.

## 7. Nhiem vu 3 - Tao whitelist carrier

Muc dich: chon cac he so AC co texture trung binh, bien do nho va `rd_margin` thap.

```bash
cat policy.txt
python3 tools/make_whitelist.py
head work/whitelist.csv
cat report/whitelist_audit.txt
```

Ket qua dung:

```text
WHITELIST=medium_ac:78,capacity_ok:yes
```

## 8. Nhiem vu 4 - Lap payload schedule

Muc dich: gan tung bit cua thong diep vao tung he so trong whitelist. Day la buoc giup analyst biet bit nao nam o block nao.

```bash
cat message/secret.txt
python3 tools/payload_manifest.py
head work/payload_schedule.csv
cat report/payload_manifest.txt
```

Ket qua dung:

```text
PAYLOAD_MANIFEST=message:QTC4,bits:32,slots:32
```

## 9. Nhiem vu 5 - Sua embedder va audit sai khac

Mo embedder:

```bash
nano tools/embed_coeff.py
```

Tim ham `adjust_parity`. Thay phan TODO bang:

```python
if mag % 2 == wanted:
    return level
if mag == 0:
    return sign
return sign * (mag + 1)
```

Chay:

```bash
python3 tools/embed_coeff.py
python3 tools/diff_audit.py
cat report/diff_audit.txt
```

Ket qua dung:

```text
STEGO_DIFF_OK=changed:16,max_delta:1
```

`max_delta:1` cho thay moi he so chi bi doi nhieu nhat 1 don vi.

## 10. Nhiem vu 6 - Sua extractor va viet ket luan

Mo extractor:

```bash
nano tools/extract_coeff.py
```

Tim TODO va them:

```python
bits.append(str(abs(level) % 2))
```

Chay:

```bash
python3 tools/extract_coeff.py
python3 tools/measure_impact.py
python3 tools/final_check.py
cat report/extracted.txt
cat report/final_check.txt
```

Ket qua dung:

```text
EXTRACTED_MESSAGE=QTC4
FINAL_STATUS=QTC4:0.04
```

Tao ket luan dieu tra:

```bash
nano answer.txt
```

Noi dung can co tren mot dong:

```text
ops-video12 QTC4 TRANSFORM_COEFF_PARITY
```

Kiem tra:

```bash
python3 tools/answer_check.py
cat report/answer_check.txt
```

Ket qua dung:

```text
ANSWER_OK=ops-video12:QTC4:TRANSFORM_COEFF_PARITY
```

## 11. Checkwork

Chay:

```bash
checkwork hevc-transform-coeff-stego
```

Checkwork cua bai:

1. `evidence_intake_report`
2. `block_frequency_profile`
3. `whitelist_policy_audit`
4. `payload_schedule_manifest`
5. `coefficient_diff_audit`
6. `incident_answer_report`

Bai nay van giu loi ky thuat transform coefficient, nhung dong goi thanh mot ca dieu tra video nghi van de sinh vien co them ngu canh thuc te.
