# Lab: hevc-transform-coeff-stego

## 1. Giới thiệu

Bài lab mô phỏng ca điều tra video H.265 nghi bị giấu tin trong hệ số transform đã lượng tử hóa. Sinh viên phân tích evidence, tạo whitelist carrier, lập payload schedule, sửa embedder/extractor và viết kết luận điều tra.

## 2. Tải và khởi động

```bash
curl -L https://github.com/letienduong/stegnography/raw/refs/heads/main/install-hevc-transform-coeff-stego.sh | bash
labtainer -r hevc-transform-coeff-stego
```

## 3. Nhiệm vụ

1. `evidence_intake_report`: xác nhận clean/suspect evidence và user `ops-video12`.
2. `block_frequency_profile`: khảo sát block 7, DC và AC coefficient.
3. `whitelist_policy_audit`: tạo whitelist carrier an toàn.
4. `payload_schedule_manifest`: lập lịch nhúng 32 bit của `QTC4`.
5. `coefficient_diff_audit`: sửa embedder, nhúng bằng parity và kiểm soát max delta.
6. `incident_answer_report`: sửa extractor, tách `QTC4` và viết kết luận.
