# Lab: hevc-transform-coeff-stego

## 1. Muc tieu

Bai lab nay khai thac he so bien doi luong tu hoa cua H.265/HEVC de giau tin. Cau truc bai khong di theo kieu chay tung script lien tuc; sinh vien se lam theo 3 pha: khao sat trace, thiet ke lich nhung, sau do audit va tach tin.

Sau bai lab, sinh vien can nam duoc:

- He so DC va AC co vai tro khac nhau trong transform block.
- Vi sao thuong chon AC coefficient thay vi DC coefficient de giau tin.
- Cach dung parity cua `abs(level)` de bieu dien bit.
- Cach lap whitelist va payload schedule truoc khi nhung.
- Cach kiem tra thay doi he so khong vuot qua nguong cho phep.

## 2. Nguyen ly

H.265 nen residual bang bien doi va luong tu hoa. Moi block co mot tap he so `level`. He so DC nam o vi tri dau, dai dien cho thanh phan trung binh. Cac he so AC nam o cac vi tri tiep theo, dai dien cho chi tiet tan so cao hon.

Trong lab nay, bit an duoc doc tu parity:

- `abs(level)` chan la bit `0`.
- `abs(level)` le la bit `1`.

Khi nhung, chi duoc doi bien do he so toi da 1 don vi va giu nguyen dau. Quy tac nay giup giam tac dong toi chat luong hinh anh.

## 3. Du lieu trong container

Bat dau trong container:

```bash
cd /home/ubuntu
ls
```

Cac file quan trong:

- `evidence/transform_coeff_trace.csv`: trace he so transform da luong tu hoa.
- `message/secret.txt`: thong diep can nhung.
- `policy.txt`: policy gioi han mien he so va bien do thay doi.
- `work/`: file trung gian do sinh vien tao.
- `report/`: file checkwork se cham.

## 4. Pha 1 - Khao sat mot block cu the

Thay vi dem toan bo trace ngay tu dau, hay xem mot block nhu khi doc analyzer:

```bash
python3 tools/block_profile.py --block 7
cat report/block_profile.txt
```

Ket qua can co:

```text
BLOCK_PROFILE=block:7,dc:10,nonzero_ac:6
```

Doc them vector he so trong file report. Ghi nho: DC khong duoc dung de nhung trong bai nay.

## 5. Pha 2 - Lap inventory cho toan trace

Tao bang tong hop DC, AC khac 0 va AC bang 0:

```bash
python3 tools/inventory_coeffs.py
cat report/inventory.txt
```

Ket qua dung:

```text
INVENTORY=dc:40,ac_nonzero:240,ac_zero:40
```

Co the tu doi chieu bang lenh shell:

```bash
head evidence/transform_coeff_trace.csv
grep ',ac,' evidence/transform_coeff_trace.csv | head
```

## 6. Pha 3 - Tao whitelist he so an toan

Kiem tra policy:

```bash
cat policy.txt
```

Policy hop le:

```text
COEFF_DOMAIN=AC
MAX_LEVEL_DELTA=1
MIN_CAPACITY_BITS=32
```

Tao whitelist:

```bash
python3 tools/make_whitelist.py
head work/whitelist.csv
cat report/whitelist_audit.txt
```

Ket qua dung:

```text
WHITELIST=medium_ac:78,capacity_ok:yes
```

Whitelist chi lay AC coefficient, texture trung binh, `rd_margin` nho va co dung luong lon hon payload.

## 7. Pha 4 - Lap payload schedule

Chuyen thong diep thanh bit va gan tung bit vao mot he so trong whitelist:

```bash
cat message/secret.txt
python3 tools/payload_manifest.py
head work/payload_schedule.csv
cat report/payload_manifest.txt
```

Ket qua dung:

```text
PAYLOAD_MANIFEST=message:QTC4,bits:32,slots:32
```

File `work/payload_schedule.csv` la bang quan trong: moi dong noi mot bit se duoc giau vao block nao va coefficient nao.

## 8. Pha 5 - Sua bo nhung va audit sai khac

Mo file:

```bash
nano tools/embed_coeff.py
```

Tim ham `adjust_parity`. Thay phan TODO bang:

```python
if mag % 2 == wanted:
    return level
if mag == 0:
    return sign
return sign * (mag + 1)
```

Chay nhung va audit:

```bash
python3 tools/embed_coeff.py
python3 tools/diff_audit.py
cat report/embed_summary.txt
cat report/diff_audit.txt
```

Ket qua dung:

```text
STEGO_DIFF_OK=changed:16,max_delta:1
```

Neu `max_delta` lon hon 1, bo nhung da lam thay doi he so qua muc policy cho phep.

## 9. Pha 6 - Sua bo tach tin va ket luan

Mo extractor:

```bash
nano tools/extract_coeff.py
```

Tim TODO va them:

```python
bits.append(str(abs(level) % 2))
```

Chay tach tin va bao cao cuoi:

```bash
python3 tools/extract_coeff.py
python3 tools/measure_impact.py
python3 tools/final_check.py
cat report/extracted.txt
cat report/impact.txt
cat report/final_check.txt
```

Ket qua dung:

```text
EXTRACTED_MESSAGE=QTC4
FINAL_STATUS=QTC4:0.04
```

Gia tri `0.04` la PSNR drop mo phong. No nho vi moi he so chi doi toi da 1 don vi.

## 10. Checkwork

Chay:

```bash
checkwork
```

Ten checkwork:

1. `block_frequency_profile`
2. `coefficient_inventory_table`
3. `whitelist_policy_audit`
4. `payload_schedule_manifest`
5. `coefficient_diff_audit`
6. `decoder_recovery_report`

Neu sai, xem file trong `report/` trung voi pha dang lam.
