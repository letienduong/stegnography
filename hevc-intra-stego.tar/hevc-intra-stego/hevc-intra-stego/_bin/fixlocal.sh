#!/bin/bash
set -e
cd /home/ubuntu
mkdir -p evidence message report
python3 tools/make_evidence.py >/dev/null
exit 0
