#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path


def from_bits(bits: str) -> str:
    raw = bytes(int(bits[i : i + 8], 2) for i in range(0, len(bits), 8))
    return raw.decode("ascii")


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("stego_csv", type=Path)
    args = parser.parse_args()

    with args.stego_csv.open(newline="", encoding="ascii") as handle:
        rows = list(csv.DictReader(handle))
    bits = []
    for row in rows:
        if not row.get("embed_bit"):
            continue
        # TODO Task 5:
        # If stego_mode equals mpm0, recover bit 0.
        # If stego_mode equals mpm1, recover bit 1.
        # Ignore rows that do not match the pair policy.
        pass
    print(f"RECOVERED_BITS={len(bits)}")
    print(f"EXTRACTED_MESSAGE={from_bits(''.join(bits))}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
