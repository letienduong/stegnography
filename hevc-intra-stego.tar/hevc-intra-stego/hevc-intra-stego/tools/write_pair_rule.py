#!/usr/bin/env python3
print("BIT_RULE=mpm0->0,mpm1->1")
