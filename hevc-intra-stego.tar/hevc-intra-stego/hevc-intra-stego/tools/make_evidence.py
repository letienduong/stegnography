#!/usr/bin/env python3
from __future__ import annotations

from pathlib import Path


def mode_triplet(index: int) -> tuple[int, int, int]:
    base = 2 + (index * 3) % 31
    return base % 35, (base + 5) % 35, (base + 11) % 35


def main() -> int:
    root = Path("/home/ubuntu")
    evidence = root / "evidence"
    message = root / "message"
    evidence.mkdir(exist_ok=True)
    message.mkdir(exist_ok=True)

    lines = ["# frame x y size mode mpm0 mpm1 mpm2 alt_mode rd_best rd_alt bits_best bits_alt psnr_drop_db"]
    for idx in range(96):
        frame = idx // 24
        x = (idx % 12) * 16
        y = ((idx // 12) % 2) * 16
        size = 16 if idx % 3 else 8
        mpm0, mpm1, mpm2 = mode_triplet(idx)
        eligible = idx < 48
        mode = mpm0 if idx % 2 == 0 else mpm1
        alt_mode = mpm1 if mode == mpm0 else mpm0
        rd_best = 100.0 + idx
        rd_gap = 0.08 if eligible else 0.19
        rd_alt = rd_best * (1.0 + rd_gap)
        bits_best = 120 + idx
        bits_alt = bits_best + (2 if eligible else 9)
        psnr_drop = 0.08 if eligible else 0.31
        lines.append(
            f"PU frame={frame} x={x} y={y} size={size} mode={mode} "
            f"mpm0={mpm0} mpm1={mpm1} mpm2={mpm2} alt_mode={alt_mode} "
            f"rd_best={rd_best:.2f} rd_alt={rd_alt:.2f} "
            f"bits_best={bits_best} bits_alt={bits_alt} psnr_drop_db={psnr_drop:.2f}"
        )

    (evidence / "hm_intra_trace.log").write_text("\n".join(lines) + "\n", encoding="ascii")
    (message / "secret.txt").write_text("HEVC2\n", encoding="ascii")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
