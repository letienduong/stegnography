#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path


FIELDS = [
    "frame",
    "x",
    "y",
    "size",
    "mode",
    "mpm0",
    "mpm1",
    "mpm2",
    "alt_mode",
    "rd_best",
    "rd_alt",
    "bits_best",
    "bits_alt",
    "psnr_drop_db",
]


def parse_line(line: str) -> dict[str, str]:
    parts = line.split()[1:]
    row = {}
    for part in parts:
        key, value = part.split("=", 1)
        row[key] = value
    return row


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("trace", type=Path)
    parser.add_argument("--csv", dest="csv_out", type=Path, required=True)
    args = parser.parse_args()

    rows = [parse_line(line) for line in args.trace.read_text(encoding="ascii").splitlines() if line.startswith("PU ")]
    args.csv_out.parent.mkdir(parents=True, exist_ok=True)
    with args.csv_out.open("w", newline="", encoding="ascii") as handle:
        writer = csv.DictWriter(handle, fieldnames=FIELDS)
        writer.writeheader()
        writer.writerows(rows)
    mpm_hits = sum(1 for row in rows if row["mode"] in {row["mpm0"], row["mpm1"], row["mpm2"]})
    print(f"TRACE_PU_COUNT={len(rows)}")
    print(f"TRACE_MPM_HITS={mpm_hits}")
    print("INTRA_MODE_SPACE=35")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
