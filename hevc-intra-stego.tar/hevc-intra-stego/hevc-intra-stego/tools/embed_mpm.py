#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path


def to_bits(text: str) -> str:
    return "".join(f"{byte:08b}" for byte in text.encode("ascii"))


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("all_modes", type=Path)
    parser.add_argument("candidates", type=Path)
    parser.add_argument("message", type=Path)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    with args.all_modes.open(newline="", encoding="ascii") as handle:
        rows = list(csv.DictReader(handle))
    with args.candidates.open(newline="", encoding="ascii") as handle:
        candidates = list(csv.DictReader(handle))
    bits = to_bits(args.message.read_text(encoding="ascii").strip())
    if len(bits) > len(candidates):
        raise SystemExit("message does not fit candidate set")

    candidate_keys = {(row["frame"], row["x"], row["y"], row["size"]): row for row in candidates}
    embedded = 0
    for row in rows:
        key = (row["frame"], row["x"], row["y"], row["size"])
        if key not in candidate_keys or embedded >= len(bits):
            row["embed_bit"] = ""
            row["stego_mode"] = row["mode"]
            continue
        bit = bits[embedded]
        row["embed_bit"] = bit
        # TODO Task 4:
        # bit 0 -> choose mpm0
        # bit 1 -> choose mpm1
        # Replace the placeholder below with the correct mode-pair mapping.
        row["stego_mode"] = row["mode"]
        embedded += 1

    args.out.parent.mkdir(parents=True, exist_ok=True)
    fieldnames = list(rows[0].keys())
    with args.out.open("w", newline="", encoding="ascii") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)
    print(f"EMBEDDED_BITS={embedded}")
    print(f"EMBEDDED_PUS={embedded}")
    print("BIT_MAPPING=mpm0:0,mpm1:1")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
