#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("csv_in", type=Path)
    parser.add_argument("--epsilon", type=float, required=True)
    parser.add_argument("--out", type=Path, required=True)
    args = parser.parse_args()

    with args.csv_in.open(newline="", encoding="ascii") as handle:
        rows = list(csv.DictReader(handle))
    chosen = []
    for row in rows:
        rd_best = float(row["rd_best"])
        rd_alt = float(row["rd_alt"])
        relative_gap = (rd_alt - rd_best) / rd_best
        pair_ok = row["mode"] in {row["mpm0"], row["mpm1"]} and row["alt_mode"] in {row["mpm0"], row["mpm1"]}
        if relative_gap <= args.epsilon and pair_ok:
            row["relative_gap"] = f"{relative_gap:.4f}"
            chosen.append(row)

    args.out.parent.mkdir(parents=True, exist_ok=True)
    fields = list(rows[0].keys()) + ["relative_gap"]
    with args.out.open("w", newline="", encoding="ascii") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(chosen)
    print(f"EPSILON={args.epsilon:.2f}")
    print(f"ELIGIBLE_PUS={len(chosen)}")
    print("PAIR_POLICY=mpm0_mpm1")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
