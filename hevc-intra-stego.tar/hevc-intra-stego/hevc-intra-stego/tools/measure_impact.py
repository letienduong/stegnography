#!/usr/bin/env python3
from __future__ import annotations

import argparse
import csv
from pathlib import Path


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("original_csv", type=Path)
    parser.add_argument("stego_csv", type=Path)
    args = parser.parse_args()

    with args.original_csv.open(newline="", encoding="ascii") as handle:
        original = list(csv.DictReader(handle))
    with args.stego_csv.open(newline="", encoding="ascii") as handle:
        stego = list(csv.DictReader(handle))

    selected_keys = {
        (row["frame"], row["x"], row["y"], row["size"])
        for row in stego
        if row.get("embed_bit")
    }
    bits_before = 0
    bits_after = 0
    quality = []
    for row in original:
        key = (row["frame"], row["x"], row["y"], row["size"])
        bits_before += int(row["bits_best"])
        if key in selected_keys:
            bits_after += int(row["bits_alt"])
            quality.append(float(row["psnr_drop_db"]))
        else:
            bits_after += int(row["bits_best"])
    bitrate_delta = ((bits_after - bits_before) / bits_before) * 100.0
    quality_drop = sum(quality) / len(quality)
    print(f"BITRATE_BEFORE={bits_before}")
    print(f"BITRATE_AFTER={bits_after}")
    print(f"BITRATE_DELTA_PERCENT={bitrate_delta:.2f}")
    print(f"QUALITY_DROP_DB={quality_drop:.2f}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
