# Lab 2: hevc-intra-stego

## 1. Gioi thieu Lab

Ten lab: `hevc-intra-stego`

Chu de: giau tin vao che do du doan noi khung HEVC thong qua danh sach MPM.

Muc tieu:

- Hieu 35 che do Intra Prediction cua HEVC.
- Doc trace PU co mode hien tai, MPM va RD cost.
- Chon PU co the thay the mode trong nguong `epsilon`.
- Nhung 1 bit/PU bang cap mode `mpm0` va `mpm1`.
- Tach thong diep va do tac dong bitrate/chat luong.

## 2. Kich ban

Sinh vien dong vai nha nghien cuu steganography tren video HEVC. Mot trace noi bo duoc cap san, mo phong ket qua tu cong cu phan tich encoder/decoder. Nhiem vu la xay dung kenh nhung tin dua tren danh sach MPM cua cac PU trong intra frame.

Y tuong chinh: neu mot PU co hai mode `mpm0` va `mpm1` gan tuong duong ve chi phi RD, dung `mpm0` bieu dien bit `0` va `mpm1` bieu dien bit `1`.

## 3. Kien thuc bo tro

- `PU`: Prediction Unit, don vi block duoc dung cho du doan noi khung.
- `35 Intra modes`: gom planar, DC va 33 huong angular.
- `MPM`: Most Probable Mode, danh sach mode co xac suat cao de ma hoa mode gon hon.
- `RD cost`: chi phi rate-distortion, can bang bitrate va sai lech tai tao.
- `epsilon`: nguong cho phep khi so sanh mode thay the voi mode tot nhat.

Du lieu duoc cap khi container khoi dong:

- `evidence/hm_intra_trace.log`
- `message/secret.txt`
- `tools/`
- `report/`

## 4. Tai va khoi dong Lab

Cach khuyen nghi: chay script cai dat de tu tai lab va kiem tra moi truong checkwork:

```bash
curl -L https://github.com/letienduong/stegnography/raw/refs/heads/main/install-hevc-intra-stego.sh | bash
```

Hoac tai lab thu cong bang mot trong hai cach sau:

```bash
imodule https://github.com/letienduong/stegnography/raw/refs/heads/main/hevc-intra-stego.tar
```

Hoac dung `curl` neu khong dung `imodule`:

```bash
curl -L https://github.com/letienduong/stegnography/raw/refs/heads/main/hevc-intra-stego.tar | tar -x -C ~/labtainer/trunk/labs/
```

Khoi dong lab:

```bash
labtainer -r hevc-intra-stego
```

Neu Labtainer yeu cau cap nhat, chay `update-labtainer.sh`, sau do chay lai lenh khoi dong lab.

## 5. Cac nhiem vu cua bai thuc hanh

Lam bai trong container tai thu muc `/home/ubuntu`.

### Nhiem vu 1 - Quan sat trace va dem so PU

```bash
head -n 5 evidence/hm_intra_trace.log > report/trace_inspection.txt
grep -c '^PU ' evidence/hm_intra_trace.log | awk '{print "PU_LINES="$1}' >> report/trace_inspection.txt
```

Ket qua can co: `PU_LINES=96`.

### Nhiem vu 2 - Parse trace va thong ke do phu mode

```bash
python3 tools/parse_intra_trace.py evidence/hm_intra_trace.log \
  --csv report/intra_modes.csv \
  > report/trace_summary.txt
awk -F, 'NR>1 {seen[$5]=1} END {for (m in seen) c++; print "OBSERVED_MODE_COUNT=" c}' \
  report/intra_modes.csv > report/mode_stats.txt
```

Ket qua can co: `OBSERVED_MODE_COUNT=35`.

### Nhiem vu 3 - Chon PU ung vien theo nguong epsilon

```bash
python3 tools/select_candidates.py report/intra_modes.csv \
  --epsilon 0.12 \
  --out report/candidates.csv \
  > report/candidates.txt
```

Ket qua can co: `ELIGIBLE_PUS=48`.

### Nhiem vu 4 - Sua code nhung thong diep bang mode pair

Mo `tools/embed_mpm.py`, hoan thanh TODO: bit `0` dung `mpm0`, bit `1` dung `mpm1`.

```bash
nano tools/embed_mpm.py
python3 tools/embed_mpm.py \
  report/intra_modes.csv \
  report/candidates.csv \
  message/secret.txt \
  --out evidence/stego_modes.csv \
  > report/embed_summary.txt
```

Ket qua can co: `EMBEDDED_BITS=40`.

### Nhiem vu 5 - Sua code tach thong diep tu trace stego

Mo `tools/extract_mpm.py`, hoan thanh TODO: `stego_mode == mpm0` them bit `0`, `stego_mode == mpm1` them bit `1`.

```bash
nano tools/extract_mpm.py
python3 tools/extract_mpm.py evidence/stego_modes.csv \
  > report/extracted.txt
```

Ket qua can co: `EXTRACTED_MESSAGE=HEVC2`.

### Nhiem vu 6 - Do tac dong bitrate va chat luong

```bash
python3 tools/measure_impact.py \
  report/intra_modes.csv \
  evidence/stego_modes.csv \
  > report/impact.txt
```

Ket qua can co: `QUALITY_DROP_DB=0.08`.

## 6. Bang tong hop ket qua mong doi

- `trace_pu_count`: `report/trace_inspection.txt` chua `PU_LINES=96`.
- `mode_space_coverage`: `report/mode_stats.txt` chua `OBSERVED_MODE_COUNT=35`.
- `epsilon_candidate_set`: `report/candidates.txt` chua `ELIGIBLE_PUS=48`.
- `mpm_pair_embedding`: `report/embed_summary.txt` chua `EMBEDDED_BITS=40`.
- `mpm_message_extract`: `report/extracted.txt` chua `EXTRACTED_MESSAGE=HEVC2`.
- `bitrate_quality_impact`: `report/impact.txt` chua `QUALITY_DROP_DB=0.08`.

Sau khi hoan thanh, chay:

```bash
checkwork hevc-intra-stego
```
