# Lab: hevc-intra-stego

## 1. Giới thiệu

Tên lab: `hevc-intra-stego`

Chủ đề: điều tra video H.265 nghi bị dùng làm kênh giấu tin trong lựa chọn Intra Prediction mode.

Vai trò của sinh viên: analyst kiểm tra trace intra đáng ngờ. Trace chứa thông tin PU, danh sách MPM và chi phí RD. Nhiệm vụ là xác định PU có thể dùng làm carrier, nhúng thông điệp bằng cặp `mpm0/mpm1`, sau đó tách lại thông điệp.

Mục tiêu:

- Hiểu 35 chế độ Intra Prediction và danh sách MPM trong HEVC.
- Parse trace PU sang CSV để phân tích.
- Chọn PU ứng viên theo ngưỡng `epsilon = 0.12`.
- Sửa embedder/extractor để giấu và tách tin bằng MPM pair.
- Đo tác động tới bitrate và chất lượng.

## 2. Kiến thức cần nắm

HEVC có 35 mode dự đoán nội khung, gồm Planar, DC và 33 mode theo hướng. Khi mã hóa mode intra, encoder dùng danh sách Most Probable Mode để biểu diễn các mode có xác suất cao bằng ít bit hơn.

Quy tắc trong bài:

- `stego_mode = mpm0` -> bit `0`.
- `stego_mode = mpm1` -> bit `1`.
- Chỉ dùng PU có chênh lệch RD cost không vượt `epsilon = 0.12`.

## 3. Dữ liệu trong lab

Vào thư mục làm bài:

```bash
cd /home/ubuntu
ls
```

Thư mục quan trọng:

- `evidence/hm_intra_trace.log`: trace PU từ mô phỏng HM-style.
- `message/secret.txt`: thông điệp dùng trong mô phỏng nhúng.
- `tools/`: công cụ parse, chọn candidate, nhúng, tách và đo impact.
- `report/`: nơi lưu kết quả để checkwork chấm.

## 4. Tải và khởi động Lab

Cách khuyến nghị: chạy script cài đặt để tự tải lab và kiểm tra môi trường checkwork:

```bash
curl -L https://github.com/letienduong/stegnography/raw/refs/heads/main/install-hevc-intra-stego.sh | bash
```

Hoặc tải lab thủ công bằng một trong hai cách sau:

```bash
imodule https://github.com/letienduong/stegnography/raw/refs/heads/main/hevc-intra-stego.tar
```

Hoặc dùng `curl` nếu không dùng `imodule`:

```bash
curl -L https://github.com/letienduong/stegnography/raw/refs/heads/main/hevc-intra-stego.tar | tar -x -C ~/labtainer/trunk/labs/
```

Khởi động lab:

```bash
labtainer -r hevc-intra-stego
```

Nếu Labtainer yêu cầu cập nhật, chạy `update-labtainer.sh`, sau đó chạy lại lệnh khởi động lab.

## 5. Nhiệm vụ 1 - Intake trace

Mục đích: quan sát trace và xác nhận có 96 Prediction Unit.

```bash
head -n 5 evidence/hm_intra_trace.log > report/trace_inspection.txt
grep -c '^PU ' evidence/hm_intra_trace.log | awk '{print "PU_LINES="$1}' >> report/trace_inspection.txt
cat report/trace_inspection.txt
```

Kết quả đúng:

```text
PU_LINES=96
```

## 6. Nhiệm vụ 2 - Parse mode space

Mục đích: chuyển trace sang CSV và xác nhận trace bao phủ đủ 35 mode intra.

```bash
python3 tools/parse_intra_trace.py evidence/hm_intra_trace.log --csv report/intra_modes.csv > report/trace_summary.txt
awk -F, 'NR>1 {seen[$5]=1} END {for (m in seen) c++; print "OBSERVED_MODE_COUNT=" c}' report/intra_modes.csv > report/mode_stats.txt
cat report/mode_stats.txt
```

Kết quả đúng:

```text
OBSERVED_MODE_COUNT=35
```

## 7. Nhiệm vụ 3 - Chọn candidate PU

Mục đích: chỉ chọn PU có mode thay thế đủ gần mode tốt nhất theo `epsilon = 0.12`.

```bash
python3 tools/select_candidates.py report/intra_modes.csv --epsilon 0.12 --out report/candidates.csv > report/candidates.txt
head report/candidates.csv
cat report/candidates.txt
```

Kết quả đúng:

```text
ELIGIBLE_PUS=48
```

## 8. Nhiệm vụ 4 - Sửa embedder

Mở embedder:

```bash
nano tools/embed_mpm.py
```

T?m TODO c?a Task 4 v? t? ho?n thi?n ?i?u ki?n ch?n mode: bit 0 d?ng nh?nh mpm0, bit 1 d?ng nh?nh mpm1. C?c PU kh?ng n?m trong candidate kh?ng ???c ??i mode.

Chạy:

```bash
python3 tools/embed_mpm.py report/intra_modes.csv report/candidates.csv message/secret.txt --out evidence/stego_modes.csv > report/embed_summary.txt
cat report/embed_summary.txt
```

Kết quả đúng:

```text
EMBEDDED_BITS=40
```

## 9. Nhiệm vụ 5 - Sửa extractor

Mở extractor:

```bash
nano tools/extract_mpm.py
```

T?m TODO c?a Task 5 v? t? ho?n thi?n ?i?u ki?n ??c bit: so s?nh stego_mode v?i mpm0/mpm1 c?a t?ng h?ng ?? suy ra 0/1. Ch? thu bit ? c?c h?ng c? ??nh d?u mang tin.

Chạy:

```bash
python3 tools/extract_mpm.py evidence/stego_modes.csv > report/extracted.txt
cat report/extracted.txt
```

Kết quả đúng:

```text
EXTRACTED_MESSAGE=HEVC2
```

## 10. Nhiệm vụ 6 - Đo impact

Mục đích: so sánh trace gốc và trace đã nhúng.

```bash
python3 tools/measure_impact.py report/intra_modes.csv evidence/stego_modes.csv > report/impact.txt
cat report/impact.txt
```

Kết quả đúng:

```text
QUALITY_DROP_DB=0.08
```

## 11. Checkwork

Chạy:

```bash
checkwork hevc-intra-stego
```

Checkwork của bài:

1. `trace_pu_count`
2. `mode_space_coverage`
3. `epsilon_candidate_set`
4. `mpm_pair_embedding`
5. `mpm_message_extract`
6. `bitrate_quality_impact`

Bài này giữ lõi kỹ thuật Intra Prediction steganography, nhưng đóng gói thành một ca điều tra trace video đáng ngờ để sinh viên có thêm ngữ cảnh thực tế.
