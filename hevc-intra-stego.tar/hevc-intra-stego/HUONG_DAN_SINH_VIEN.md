# Lab 2: hevc-intra-stego

## 1. Giới thiệu Lab

Tên lab: `hevc-intra-stego`

Chủ đề: giấu tin vào chế độ dự đoán nội khung HEVC thông qua danh sách MPM.

Mục tiêu:

- Hiểu 35 chế độ Intra Prediction của HEVC.
- Đọc trace PU có mode hiện tại, MPM và RD cost.
- Chọn PU có thể thay thế mode trong ngưỡng `epsilon`.
- Nhúng 1 bit/PU bằng cặp mode `mpm0` và `mpm1`.
- Tách thông điệp và đo tác động bitrate/chất lượng.

## 2. Kịch bản

Sinh viên đóng vai nhà nghiên cứu steganography trên video HEVC. Một trace nội bộ được cấp sẵn, mô phỏng kết quả từ công cụ phân tích encoder/decoder. Nhiệm vụ là xây dựng kênh nhúng tin dựa trên danh sách MPM của các PU trong intra frame.

Ý tưởng chính: nếu một PU có hai mode `mpm0` và `mpm1` gần tương đương về chi phí RD, dùng `mpm0` biểu diễn bit `0` và `mpm1` biểu diễn bit `1`.

## 3. Kiến thức bổ trợ

- `PU`: Prediction Unit, đơn vị block được dùng cho dự đoán nội khung.
- `35 Intra modes`: gồm planar, DC và 33 hướng angular.
- `MPM`: Most Probable Mode, danh sách mode có xác suất cao để mã hóa mode gọn hơn.
- `RD cost`: chi phí rate-distortion, cân bằng bitrate và sai lệch tái tạo.
- `epsilon`: ngưỡng cho phép khi so sánh mode thay thế với mode tốt nhất.

Dữ liệu được cấp khi container khởi động:

- `evidence/hm_intra_trace.log`
- `message/secret.txt`
- `tools/`
- `report/`

## 4. Tải và khởi động Lab

Cách khuyến nghị: chạy script cài đặt để tự tải lab và kiểm tra môi trường checkwork:

```bash
curl -L https://github.com/letienduong/stegnography/raw/refs/heads/main/install-hevc-intra-stego.sh | bash
```

Hoặc tải lab thủ công bằng một trong hai cách sau:

```bash
imodule https://github.com/letienduong/stegnography/raw/refs/heads/main/hevc-intra-stego.tar
```

Hoặc dùng `curl` nếu không dùng `imodule`:

```bash
curl -L https://github.com/letienduong/stegnography/raw/refs/heads/main/hevc-intra-stego.tar | tar -x -C ~/labtainer/trunk/labs/
```

Khởi động lab:

```bash
labtainer -r hevc-intra-stego
```

Nếu Labtainer yêu cầu cập nhật, chạy `update-labtainer.sh`, sau đó chạy lại lệnh khởi động lab.

## 5. Các nhiệm vụ của bài thực hành

Làm bài trong container tại thư mục `/home/ubuntu`.

### Nhiệm vụ 1 - Quan sát trace và đếm số PU

```bash
head -n 5 evidence/hm_intra_trace.log > report/trace_inspection.txt
grep -c '^PU ' evidence/hm_intra_trace.log | awk '{print "PU_LINES="$1}' >> report/trace_inspection.txt
```

Kết quả cần có: `PU_LINES=96`.

### Nhiệm vụ 2 - Parse trace và thống kê độ phủ mode

```bash
python3 tools/parse_intra_trace.py evidence/hm_intra_trace.log \
  --csv report/intra_modes.csv \
  > report/trace_summary.txt
awk -F, 'NR>1 {seen[$5]=1} END {for (m in seen) c++; print "OBSERVED_MODE_COUNT=" c}' \
  report/intra_modes.csv > report/mode_stats.txt
```

Kết quả cần có: `OBSERVED_MODE_COUNT=35`.

### Nhiệm vụ 3 - Chọn PU ứng viên theo ngưỡng epsilon

```bash
python3 tools/select_candidates.py report/intra_modes.csv \
  --epsilon 0.12 \
  --out report/candidates.csv \
  > report/candidates.txt
```

Kết quả cần có: `ELIGIBLE_PUS=48`.

### Nhiệm vụ 4 - Sửa code nhúng thông điệp bằng mode pair

Mở `tools/embed_mpm.py`, hoàn thành TODO: bit `0` dùng `mpm0`, bit `1` dùng `mpm1`.

```bash
nano tools/embed_mpm.py
python3 tools/embed_mpm.py \
  report/intra_modes.csv \
  report/candidates.csv \
  message/secret.txt \
  --out evidence/stego_modes.csv \
  > report/embed_summary.txt
```

Kết quả cần có: `EMBEDDED_BITS=40`.

### Nhiệm vụ 5 - Sửa code tách thông điệp từ trace stego

Mở `tools/extract_mpm.py`, hoàn thành TODO: `stego_mode == mpm0` thêm bit `0`, `stego_mode == mpm1` thêm bit `1`.

```bash
nano tools/extract_mpm.py
python3 tools/extract_mpm.py evidence/stego_modes.csv \
  > report/extracted.txt
```

Kết quả cần có: `EXTRACTED_MESSAGE=HEVC2`.

### Nhiệm vụ 6 - Đo tác động bitrate và chất lượng

```bash
python3 tools/measure_impact.py \
  report/intra_modes.csv \
  evidence/stego_modes.csv \
  > report/impact.txt
```

Kết quả cần có: `QUALITY_DROP_DB=0.08`.

## 6. Bảng tổng hợp kết quả mong đợi

- `trace_pu_count`: `report/trace_inspection.txt` chứa `PU_LINES=96`.
- `mode_space_coverage`: `report/mode_stats.txt` chứa `OBSERVED_MODE_COUNT=35`.
- `epsilon_candidate_set`: `report/candidates.txt` chứa `ELIGIBLE_PUS=48`.
- `mpm_pair_embedding`: `report/embed_summary.txt` chứa `EMBEDDED_BITS=40`.
- `mpm_message_extract`: `report/extracted.txt` chứa `EXTRACTED_MESSAGE=HEVC2`.
- `bitrate_quality_impact`: `report/impact.txt` chứa `QUALITY_DROP_DB=0.08`.

Sau khi hoàn thành, chạy:

```bash
checkwork hevc-intra-stego
```
